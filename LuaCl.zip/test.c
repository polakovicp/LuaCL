#include <stdio.h>


int main()
{
    SomeFunction("Ahoj");

    return 0;
}
