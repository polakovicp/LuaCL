#ifndef __MAIN_H__
#define __MAIN_H__

/*  To use this exported function of dll, include this header
 *  in your project.
 */
#ifdef _WIN32
  #ifdef BUILD_DLL
    #define DLL_EXPORT __declspec(dllexport)
  #else
    #define DLL_EXPORT __declspec(dllimport)
  #endif
  #include <windows.h>
  #include <stdint.h>     // defines opencl types
  #include <CL/opencl.h>
#else
  #ifdef BUILD_DLL
    #define DLL_EXPORT
  #else
    #define DLL_EXPORT extern
  #endif
#endif

#ifdef __cplusplus
extern "C"
{
#endif

    #include "lua.h"
    #include "lauxlib.h"
    #include "lualib.h"

    int get_enum(lua_State * L, int position);
    DLL_EXPORT int luaopen_cl (lua_State *L);

#ifdef __cplusplus
}
#endif

cl_int err;

typedef struct _cl_enum {
  const char *cl;
  int value;
} cl_enum;

static const cl_enum cl_const[] = {
    /* Error Codes */
    { "CL_SUCCESS"                                  , CL_SUCCESS},
    { "CL_DEVICE_NOT_FOUND"                         , CL_DEVICE_NOT_FOUND},
    { "CL_DEVICE_NOT_AVAILABLE"                     , CL_DEVICE_NOT_AVAILABLE},
    { "CL_COMPILER_NOT_AVAILABLE"                   , CL_COMPILER_NOT_AVAILABLE},
    { "CL_MEM_OBJECT_ALLOCATION_FAILURE"            , CL_MEM_OBJECT_ALLOCATION_FAILURE},
    { "CL_OUT_OF_RESOURCES"                         , CL_OUT_OF_RESOURCES},
    { "CL_OUT_OF_HOST_MEMORY"                       , CL_OUT_OF_HOST_MEMORY},
    { "CL_PROFILING_INFO_NOT_AVAILABLE"             , CL_PROFILING_INFO_NOT_AVAILABLE},
    { "CL_MEM_COPY_OVERLAP"                         , CL_MEM_COPY_OVERLAP},
    { "CL_IMAGE_FORMAT_MISMATCH"                    , CL_IMAGE_FORMAT_MISMATCH},
    { "CL_IMAGE_FORMAT_NOT_SUPPORTED"               , CL_IMAGE_FORMAT_NOT_SUPPORTED},
    { "CL_BUILD_PROGRAM_FAILURE"                    , CL_BUILD_PROGRAM_FAILURE},
    { "CL_MAP_FAILURE"                              , CL_MAP_FAILURE},
    { "CL_INVALID_VALUE"                            , CL_INVALID_VALUE},
    { "CL_INVALID_DEVICE_TYPE"                      , CL_INVALID_DEVICE_TYPE},
    { "CL_INVALID_PLATFORM"                         , CL_INVALID_PLATFORM},
    { "CL_INVALID_DEVICE"                           , CL_INVALID_DEVICE},
    { "CL_INVALID_CONTEXT"                          , CL_INVALID_CONTEXT},
    { "CL_INVALID_QUEUE_PROPERTIES"                 , CL_INVALID_QUEUE_PROPERTIES},
    { "CL_INVALID_COMMAND_QUEUE"                    , CL_INVALID_COMMAND_QUEUE},
    { "CL_INVALID_HOST_PTR"                         , CL_INVALID_HOST_PTR},
    { "CL_INVALID_MEM_OBJECT"                       , CL_INVALID_MEM_OBJECT},
    { "CL_INVALID_IMAGE_FORMAT_DESCRIPTOR"          , CL_INVALID_IMAGE_FORMAT_DESCRIPTOR},
    { "CL_INVALID_IMAGE_SIZE"                       , CL_INVALID_IMAGE_SIZE},
    { "CL_INVALID_SAMPLER"                          , CL_INVALID_SAMPLER},
    { "CL_INVALID_BINARY"                           , CL_INVALID_BINARY},
    { "CL_INVALID_BUILD_OPTIONS"                    , CL_INVALID_BUILD_OPTIONS},
    { "CL_INVALID_PROGRAM"                          , CL_INVALID_PROGRAM},
    { "CL_INVALID_PROGRAM_EXECUTABLE"               , CL_INVALID_PROGRAM_EXECUTABLE},
    { "CL_INVALID_KERNEL_NAME"                      , CL_INVALID_KERNEL_NAME},
    { "CL_INVALID_KERNEL_DEFINITION"                , CL_INVALID_KERNEL_DEFINITION},
    { "CL_INVALID_KERNEL"                           , CL_INVALID_KERNEL},
    { "CL_INVALID_ARG_INDEX"                        , CL_INVALID_ARG_INDEX},
    { "CL_INVALID_ARG_VALUE"                        , CL_INVALID_ARG_VALUE},
    { "CL_INVALID_ARG_SIZE"                         , CL_INVALID_ARG_SIZE},
    { "CL_INVALID_KERNEL_ARGS"                      , CL_INVALID_KERNEL_ARGS},
    { "CL_INVALID_WORK_DIMENSION"                   , CL_INVALID_WORK_DIMENSION},
    { "CL_INVALID_WORK_GROUP_SIZE"                  , CL_INVALID_WORK_GROUP_SIZE},
    { "CL_INVALID_WORK_ITEM_SIZE"                   , CL_INVALID_WORK_ITEM_SIZE},
    { "CL_INVALID_GLOBAL_OFFSET"                    , CL_INVALID_GLOBAL_OFFSET},
    { "CL_INVALID_EVENT_WAIT_LIST"                  , CL_INVALID_EVENT_WAIT_LIST},
    { "CL_INVALID_EVENT"                            , CL_INVALID_EVENT},
    { "CL_INVALID_OPERATION"                        , CL_INVALID_OPERATION},
    { "CL_INVALID_GL_OBJECT"                        , CL_INVALID_GL_OBJECT},
    { "CL_INVALID_BUFFER_SIZE"                      , CL_INVALID_BUFFER_SIZE},
    { "CL_INVALID_MIP_LEVEL"                        , CL_INVALID_MIP_LEVEL},
    { "CL_INVALID_GLOBAL_WORK_SIZE"                 , CL_INVALID_GLOBAL_WORK_SIZE},
    /* OpenCL Version */
    { "CL_VERSION_1_0"                              , CL_VERSION_1_0},
    /* cl_bool */
    { "CL_FALSE"                                    , CL_FALSE},
    { "CL_TRUE"                                     , CL_TRUE},
    /* cl_platform_info */
    { "CL_PLATFORM_PROFILE"                         , CL_PLATFORM_PROFILE},
    { "CL_PLATFORM_VERSION"                         , CL_PLATFORM_VERSION},
    { "CL_PLATFORM_NAME"                            , CL_PLATFORM_NAME},
    { "CL_PLATFORM_VENDOR"                          , CL_PLATFORM_VENDOR},
    { "CL_PLATFORM_EXTENSIONS"                      , CL_PLATFORM_EXTENSIONS},
    /* cl_device_type - bitfield */
    { "CL_DEVICE_TYPE_DEFAULT"                      , CL_DEVICE_TYPE_DEFAULT},
    { "CL_DEVICE_TYPE_CPU"                          , CL_DEVICE_TYPE_CPU},
    { "CL_DEVICE_TYPE_GPU"                          , CL_DEVICE_TYPE_GPU},
    { "CL_DEVICE_TYPE_ACCELERATOR"                  , CL_DEVICE_TYPE_ACCELERATOR},
    { "CL_DEVICE_TYPE_ALL"                          , CL_DEVICE_TYPE_ALL},
    /* cl_device_info */
    { "CL_DEVICE_TYPE"                              , CL_DEVICE_TYPE},
    { "CL_DEVICE_VENDOR_ID"                         , CL_DEVICE_VENDOR_ID},
    { "CL_DEVICE_MAX_COMPUTE_UNITS"                 , CL_DEVICE_MAX_COMPUTE_UNITS},
    { "CL_DEVICE_MAX_WORK_ITEM_DIMENSIONS"          , CL_DEVICE_MAX_WORK_ITEM_DIMENSIONS},
    { "CL_DEVICE_MAX_WORK_GROUP_SIZE"               , CL_DEVICE_MAX_WORK_GROUP_SIZE},
    { "CL_DEVICE_MAX_WORK_ITEM_SIZES"               , CL_DEVICE_MAX_WORK_ITEM_SIZES},
    { "CL_DEVICE_PREFERRED_VECTOR_WIDTH_CHAR"       , CL_DEVICE_PREFERRED_VECTOR_WIDTH_CHAR},
    { "CL_DEVICE_PREFERRED_VECTOR_WIDTH_SHORT"      , CL_DEVICE_PREFERRED_VECTOR_WIDTH_SHORT},
    { "CL_DEVICE_PREFERRED_VECTOR_WIDTH_INT"        , CL_DEVICE_PREFERRED_VECTOR_WIDTH_INT},
    { "CL_DEVICE_PREFERRED_VECTOR_WIDTH_LONG"       , CL_DEVICE_PREFERRED_VECTOR_WIDTH_LONG},
    { "CL_DEVICE_PREFERRED_VECTOR_WIDTH_FLOAT"      , CL_DEVICE_PREFERRED_VECTOR_WIDTH_FLOAT},
    { "CL_DEVICE_PREFERRED_VECTOR_WIDTH_DOUBLE"     , CL_DEVICE_PREFERRED_VECTOR_WIDTH_DOUBLE},
    { "CL_DEVICE_MAX_CLOCK_FREQUENCY"               , CL_DEVICE_MAX_CLOCK_FREQUENCY},
    { "CL_DEVICE_ADDRESS_BITS"                      , CL_DEVICE_ADDRESS_BITS},
    { "CL_DEVICE_MAX_READ_IMAGE_ARGS"               , CL_DEVICE_MAX_READ_IMAGE_ARGS},
    { "CL_DEVICE_MAX_WRITE_IMAGE_ARGS"              , CL_DEVICE_MAX_WRITE_IMAGE_ARGS},
    { "CL_DEVICE_MAX_MEM_ALLOC_SIZE"                , CL_DEVICE_MAX_MEM_ALLOC_SIZE},
    { "CL_DEVICE_IMAGE2D_MAX_WIDTH"                 , CL_DEVICE_IMAGE2D_MAX_WIDTH},
    { "CL_DEVICE_IMAGE2D_MAX_HEIGHT"                , CL_DEVICE_IMAGE2D_MAX_HEIGHT},
    { "CL_DEVICE_IMAGE3D_MAX_WIDTH"                 , CL_DEVICE_IMAGE3D_MAX_WIDTH},
    { "CL_DEVICE_IMAGE3D_MAX_HEIGHT"                , CL_DEVICE_IMAGE3D_MAX_HEIGHT},
    { "CL_DEVICE_IMAGE3D_MAX_DEPTH"                 , CL_DEVICE_IMAGE3D_MAX_DEPTH},
    { "CL_DEVICE_IMAGE_SUPPORT"                     , CL_DEVICE_IMAGE_SUPPORT},
    { "CL_DEVICE_MAX_PARAMETER_SIZE"                , CL_DEVICE_MAX_PARAMETER_SIZE},
    { "CL_DEVICE_MAX_SAMPLERS"                      , CL_DEVICE_MAX_SAMPLERS},
    { "CL_DEVICE_MEM_BASE_ADDR_ALIGN"               , CL_DEVICE_MEM_BASE_ADDR_ALIGN},
    { "CL_DEVICE_MIN_DATA_TYPE_ALIGN_SIZE"          , CL_DEVICE_MIN_DATA_TYPE_ALIGN_SIZE},
    { "CL_DEVICE_SINGLE_FP_CONFIG"                  , CL_DEVICE_SINGLE_FP_CONFIG},
    { "CL_DEVICE_GLOBAL_MEM_CACHE_TYPE"             , CL_DEVICE_GLOBAL_MEM_CACHE_TYPE},
    { "CL_DEVICE_GLOBAL_MEM_CACHELINE_SIZE"         , CL_DEVICE_GLOBAL_MEM_CACHELINE_SIZE},
    { "CL_DEVICE_GLOBAL_MEM_CACHE_SIZE"             , CL_DEVICE_GLOBAL_MEM_CACHE_SIZE},
    { "CL_DEVICE_GLOBAL_MEM_SIZE"                   , CL_DEVICE_GLOBAL_MEM_SIZE},
    { "CL_DEVICE_MAX_CONSTANT_BUFFER_SIZE"          , CL_DEVICE_MAX_CONSTANT_BUFFER_SIZE},
    { "CL_DEVICE_MAX_CONSTANT_ARGS"                 , CL_DEVICE_MAX_CONSTANT_ARGS},
    { "CL_DEVICE_LOCAL_MEM_TYPE"                    , CL_DEVICE_LOCAL_MEM_TYPE},
    { "CL_DEVICE_LOCAL_MEM_SIZE"                    , CL_DEVICE_LOCAL_MEM_SIZE},
    { "CL_DEVICE_ERROR_CORRECTION_SUPPORT"          , CL_DEVICE_ERROR_CORRECTION_SUPPORT},
    { "CL_DEVICE_PROFILING_TIMER_RESOLUTION"        , CL_DEVICE_PROFILING_TIMER_RESOLUTION},
    { "CL_DEVICE_ENDIAN_LITTLE"                     , CL_DEVICE_ENDIAN_LITTLE},
    { "CL_DEVICE_AVAILABLE"                         , CL_DEVICE_AVAILABLE},
    { "CL_DEVICE_COMPILER_AVAILABLE"                , CL_DEVICE_COMPILER_AVAILABLE},
    { "CL_DEVICE_EXECUTION_CAPABILITIES"            , CL_DEVICE_EXECUTION_CAPABILITIES},
    { "CL_DEVICE_QUEUE_PROPERTIES"                  , CL_DEVICE_QUEUE_PROPERTIES},
    { "CL_DEVICE_NAME"                              , CL_DEVICE_NAME},
    { "CL_DEVICE_VENDOR"                            , CL_DEVICE_VENDOR},
    { "CL_DRIVER_VERSION"                           , CL_DRIVER_VERSION},
    { "CL_DEVICE_PROFILE"                              , CL_DEVICE_PROFILE},
    { "CL_DEVICE_VERSION"                           , CL_DEVICE_VERSION},
    { "CL_DEVICE_EXTENSIONS"                        , CL_DEVICE_EXTENSIONS},
    { "CL_DEVICE_PLATFORM"                          , CL_DEVICE_PLATFORM},
    /* cl_device_fp_config - bitfield */
    { "CL_FP_DENORM"                                , CL_FP_DENORM},
    { "CL_FP_INF_NAN"                               , CL_FP_INF_NAN},
    { "CL_FP_ROUND_TO_NEAREST"                      , CL_FP_ROUND_TO_NEAREST},
    { "CL_FP_ROUND_TO_ZERO"                         , CL_FP_ROUND_TO_ZERO},
    { "CL_FP_ROUND_TO_INF"                          , CL_FP_ROUND_TO_INF},
    { "CL_FP_FMA"                                   , CL_FP_FMA},
    /* cl_device_mem_cache_type */
    { "CL_NONE"                                     , CL_NONE},
    { "CL_READ_ONLY_CACHE"                          , CL_READ_ONLY_CACHE},
    { "CL_READ_WRITE_CACHE"                         , CL_READ_WRITE_CACHE},
    /* cl_device_local_mem_type */
    { "CL_LOCAL"                                    , CL_LOCAL},
    { "CL_GLOBAL"                                   , CL_GLOBAL},
    /* cl_device_exec_capabilities - bitfield */
    { "CL_EXEC_KERNEL"                              , CL_EXEC_KERNEL},
    { "CL_EXEC_NATIVE_KERNEL"                       , CL_EXEC_NATIVE_KERNEL},
    /* cl_command_queue_properties - bitfield */
    { "CL_QUEUE_OUT_OF_ORDER_EXEC_MODE_ENABLE"      , CL_QUEUE_OUT_OF_ORDER_EXEC_MODE_ENABLE},
    { "CL_QUEUE_PROFILING_ENABLE"                   , CL_QUEUE_PROFILING_ENABLE},
    /* cl_context_info  */
    { "CL_CONTEXT_REFERENCE_COUNT"                  , CL_CONTEXT_REFERENCE_COUNT},
    { "CL_CONTEXT_DEVICES"                          , CL_CONTEXT_DEVICES},
    { "CL_CONTEXT_PROPERTIES"                       , CL_CONTEXT_PROPERTIES},
    /* cl_context_info + cl_context_properties */
    { "CL_CONTEXT_PLATFORM"                         , CL_CONTEXT_PLATFORM},
    /* cl_command_queue_info */
    { "CL_QUEUE_CONTEXT"                            , CL_QUEUE_CONTEXT},
    { "CL_QUEUE_DEVICE"                             , CL_QUEUE_DEVICE},
    { "CL_QUEUE_REFERENCE_COUNT"                    , CL_QUEUE_REFERENCE_COUNT},
    { "CL_QUEUE_PROPERTIES"                         , CL_QUEUE_PROPERTIES},
    /* cl_mem_flags - bitfield */
    { "CL_MEM_READ_WRITE"                           , CL_MEM_READ_WRITE},
    { "CL_MEM_WRITE_ONLY"                           , CL_MEM_WRITE_ONLY},
    { "CL_MEM_READ_ONLY"                            , CL_MEM_READ_ONLY},
    { "CL_MEM_USE_HOST_PTR"                         , CL_MEM_USE_HOST_PTR},
    { "CL_MEM_ALLOC_HOST_PTR"                       , CL_MEM_ALLOC_HOST_PTR},
    { "CL_MEM_COPY_HOST_PTR"                        , CL_MEM_COPY_HOST_PTR},
    /* cl_channel_order */
    { "CL_R"                                        , CL_R},
    { "CL_A"                                        , CL_A},
    { "CL_RG"                                       , CL_RG},
    { "CL_RA"                                       , CL_RA},
    { "CL_RGB"                                      , CL_RGB},
    { "CL_RGBA"                                     , CL_RGBA},
    { "CL_BGRA"                                     , CL_BGRA},
    { "CL_ARGB"                                     , CL_ARGB},
    { "CL_INTENSITY"                                , CL_INTENSITY},
    { "CL_LUMINANCE"                                , CL_LUMINANCE},
    /* cl_channel_type */
    { "CL_SNORM_INT8"                               , CL_SNORM_INT8},
    { "CL_SNORM_INT16"                              , CL_SNORM_INT16},
    { "CL_UNORM_INT8"                               , CL_UNORM_INT8},
    { "CL_UNORM_INT16"                              , CL_UNORM_INT16},
    { "CL_UNORM_SHORT_565"                          , CL_UNORM_SHORT_565},
    { "CL_UNORM_SHORT_555"                          , CL_UNORM_SHORT_555},
    { "CL_UNORM_INT_101010"                         , CL_UNORM_INT_101010},
    { "CL_SIGNED_INT8"                              , CL_SIGNED_INT8},
    { "CL_SIGNED_INT16"                             , CL_SIGNED_INT16},
    { "CL_SIGNED_INT32"                             , CL_SIGNED_INT32},
    { "CL_UNSIGNED_INT8"                            , CL_UNSIGNED_INT8},
    { "CL_UNSIGNED_INT16"                           , CL_UNSIGNED_INT16},
    { "CL_UNSIGNED_INT32"                           , CL_UNSIGNED_INT32},
    { "CL_HALF_FLOAT"                               , CL_HALF_FLOAT},
    { "CL_FLOAT"                                    , CL_FLOAT},
    /* cl_mem_object_type */
    { "CL_MEM_OBJECT_BUFFER"                        , CL_MEM_OBJECT_BUFFER},
    { "CL_MEM_OBJECT_IMAGE2D"                       , CL_MEM_OBJECT_IMAGE2D},
    { "CL_MEM_OBJECT_IMAGE3D"                       , CL_MEM_OBJECT_IMAGE3D},
    /* cl_mem_info */
    { "CL_MEM_TYPE"                                 , CL_MEM_TYPE},
    { "CL_MEM_FLAGS"                                , CL_MEM_FLAGS},
    { "CL_MEM_SIZE"                                 , CL_MEM_SIZE},
    { "CL_MEM_HOST_PTR"                             , CL_MEM_HOST_PTR},
    { "CL_MEM_MAP_COUNT"                            , CL_MEM_MAP_COUNT},
    { "CL_MEM_REFERENCE_COUNT"                      , CL_MEM_REFERENCE_COUNT},
    { "CL_MEM_CONTEXT"                              , CL_MEM_CONTEXT},
    /* cl_image_info */
    { "CL_IMAGE_FORMAT"                             , CL_IMAGE_FORMAT},
    { "CL_IMAGE_ELEMENT_SIZE"                       , CL_IMAGE_ELEMENT_SIZE},
    { "CL_IMAGE_ROW_PITCH"                          , CL_IMAGE_ROW_PITCH},
    { "CL_IMAGE_SLICE_PITCH"                        , CL_IMAGE_SLICE_PITCH},
    { "CL_IMAGE_WIDTH"                              , CL_IMAGE_WIDTH},
    { "CL_IMAGE_HEIGHT"                             , CL_IMAGE_HEIGHT},
    { "CL_IMAGE_DEPTH"                              , CL_IMAGE_DEPTH},
    /* cl_addressing_mode */
    { "CL_ADDRESS_NONE"                             , CL_ADDRESS_NONE},
    { "CL_ADDRESS_CLAMP_TO_EDGE"                    , CL_ADDRESS_CLAMP_TO_EDGE},
    { "CL_ADDRESS_CLAMP"                            , CL_ADDRESS_CLAMP},
    { "CL_ADDRESS_REPEAT"                           , CL_ADDRESS_REPEAT},
    /* cl_filter_mode */
    { "CL_FILTER_NEAREST"                           , CL_FILTER_NEAREST},
    { "CL_FILTER_LINEAR"                            , CL_FILTER_LINEAR},
    /* cl_sampler_info */
    { "CL_SAMPLER_REFERENCE_COUNT"                  , CL_SAMPLER_REFERENCE_COUNT},
    { "CL_SAMPLER_CONTEXT"                          , CL_SAMPLER_CONTEXT},
    { "CL_SAMPLER_NORMALIZED_COORDS"                , CL_SAMPLER_NORMALIZED_COORDS},
    { "CL_SAMPLER_ADDRESSING_MODE"                  , CL_SAMPLER_ADDRESSING_MODE},
    { "CL_SAMPLER_FILTER_MODE"                      , CL_SAMPLER_FILTER_MODE},
    /* cl_map_flags - bitfield */
    { "CL_CL_MAP_READ"                              , CL_MAP_READ},
    { "CL_CL_MAP_WRITE"                             , CL_MAP_WRITE},
    /* cl_program_info */
    { "CL_PROGRAM_REFERENCE_COUNT"                  , CL_PROGRAM_REFERENCE_COUNT},
    { "CL_PROGRAM_CONTEXT"                          , CL_PROGRAM_CONTEXT},
    { "CL_PROGRAM_NUM_DEVICES"                      , CL_PROGRAM_NUM_DEVICES},
    { "CL_PROGRAM_DEVICES"                          , CL_PROGRAM_DEVICES},
    { "CL_PROGRAM_SOURCE"                           , CL_PROGRAM_SOURCE},
    { "CL_PROGRAM_BINARY_SIZES"                     , CL_PROGRAM_BINARY_SIZES},
    { "CL_PROGRAM_BINARIES"                         , CL_PROGRAM_BINARIES},
    /* cl_program_build_info */
    { "CL_PROGRAM_BUILD_STATUS"                     , CL_PROGRAM_BUILD_STATUS},
    { "CL_PROGRAM_BUILD_OPTIONS"                    , CL_PROGRAM_BUILD_OPTIONS},
    { "CL_PROGRAM_BUILD_LOG"                        , CL_PROGRAM_BUILD_LOG},
    /* cl_build_status */
    { "CL_BUILD_SUCCESS"                            , CL_BUILD_SUCCESS},
    { "CL_BUILD_NONE"                               , CL_BUILD_NONE},
    { "CL_BUILD_ERROR"                              , CL_BUILD_ERROR},
    { "CL_BUILD_IN_PROGRESS"                        , CL_BUILD_IN_PROGRESS},
    /* cl_kernel_info */
    { "CL_KERNEL_FUNCTION_NAME"                     , CL_KERNEL_FUNCTION_NAME},
    { "CL_KERNEL_NUM_ARGS"                          , CL_KERNEL_NUM_ARGS},
    { "CL_KERNEL_REFERENCE_COUNT"                   , CL_KERNEL_REFERENCE_COUNT},
    { "CL_KERNEL_CONTEXT"                           , CL_KERNEL_CONTEXT},
    { "CL_KERNEL_PROGRAM"                           , CL_KERNEL_PROGRAM},
    /* cl_kernel_work_group_info */
    { "CL_KERNEL_WORK_GROUP_SIZE"                   , CL_KERNEL_WORK_GROUP_SIZE},
    { "CL_KERNEL_COMPILE_WORK_GROUP_SIZE"           , CL_KERNEL_COMPILE_WORK_GROUP_SIZE},
    { "CL_KERNEL_LOCAL_MEM_SIZE"                    , CL_KERNEL_LOCAL_MEM_SIZE},
    /* cl_event_info  */
    { "CL_EVENT_COMMAND_QUEUE"                      , CL_EVENT_COMMAND_QUEUE},
    { "CL_EVENT_COMMAND_TYPE"                       , CL_EVENT_COMMAND_TYPE},
    { "CL_EVENT_REFERENCE_COUNT"                    , CL_EVENT_REFERENCE_COUNT},
    { "CL_EVENT_COMMAND_EXECUTION_STATUS"           , CL_EVENT_COMMAND_EXECUTION_STATUS},
    /* cl_command_type */
    { "CL_COMMAND_NDRANGE_KERNEL"                   , CL_COMMAND_NDRANGE_KERNEL},
    { "CL_COMMAND_TASK"                             , CL_COMMAND_TASK},
    { "CL_COMMAND_NATIVE_KERNEL"                    , CL_COMMAND_NATIVE_KERNEL},
    { "CL_COMMAND_READ_BUFFER"                      , CL_COMMAND_READ_BUFFER},
    { "CL_COMMAND_WRITE_BUFFER"                     , CL_COMMAND_WRITE_BUFFER},
    { "CL_COMMAND_COPY_BUFFER"                      , CL_COMMAND_COPY_BUFFER},
    { "CL_COMMAND_READ_IMAGE"                       , CL_COMMAND_READ_IMAGE},
    { "CL_COMMAND_WRITE_IMAGE"                      , CL_COMMAND_WRITE_IMAGE},
    { "CL_COMMAND_COPY_IMAGE"                       , CL_COMMAND_COPY_IMAGE},
    { "CL_COMMAND_COPY_IMAGE_TO_BUFFER"             , CL_COMMAND_COPY_IMAGE_TO_BUFFER},
    { "CL_COMMAND_COPY_BUFFER_TO_IMAGE"             , CL_COMMAND_COPY_BUFFER_TO_IMAGE},
    { "CL_COMMAND_MAP_BUFFER"                       , CL_COMMAND_MAP_BUFFER},
    { "CL_COMMAND_MAP_IMAGE"                        , CL_COMMAND_MAP_IMAGE},
    { "CL_COMMAND_UNMAP_MEM_OBJECT"                 , CL_COMMAND_UNMAP_MEM_OBJECT},
    { "CL_COMMAND_MARKER"                           , CL_COMMAND_MARKER},
    { "CL_COMMAND_ACQUIRE_GL_OBJECTS"               , CL_COMMAND_ACQUIRE_GL_OBJECTS},
    { "CL_COMMAND_RELEASE_GL_OBJECTS"               , CL_COMMAND_RELEASE_GL_OBJECTS},
    /* command execution status */
    { "CL_COMPLETE"                                 , CL_COMPLETE},
    { "CL_RUNNING"                                  , CL_RUNNING},
    { "CL_SUBMITTED"                                , CL_SUBMITTED},
    { "CL_QUEUED"                                   , CL_QUEUED},
    /* cl_profiling_info  */
    { "CL_PROFILING_COMMAND_QUEUED"                 , CL_PROFILING_COMMAND_QUEUED},
    { "CL_PROFILING_COMMAND_SUBMIT"                 , CL_PROFILING_COMMAND_SUBMIT},
    { "CL_PROFILING_COMMAND_START"                  , CL_PROFILING_COMMAND_START},
    { "CL_PROFILING_COMMAND_END"                    , CL_PROFILING_COMMAND_END},
    /* lua types */
    { "LUA_NUMBER"                                  , sizeof(LUA_NUMBER)},
    { "CL_UINT"                                     , sizeof(cl_uint)},
    { NULL                                          , 0},
};
#endif // __MAIN_H__
