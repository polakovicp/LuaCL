#define BUILD_DLL

#include "main.h"

#ifdef __cplusplus
extern "C"
{
#endif
//-------------------------------------------------------------PERFORMANCE COUNTER
#ifdef _WIN32
static int performaceTimer(lua_State * L)
{
    lua_pushnumber(L, GetTickCount());
    return 1;
}
#endif
//---------------------------------------------------------------------------DEBUG
static int deb1(lua_State *L)
{  /*
        lua_pushstring(L, "1");
        lua_gettable(L, 2);
     printf("%d\n",
              lua_tonumber(L, 1));
  */

    lua_rawgeti(L, 1, 1);

    printf("%p\n", lua_touserdata(L, -1));

}
static int deb2(lua_State *L)
{
    lua_newtable(L);
    for(unsigned int i = 0; i < 3; i++)
       {
           lua_pushnumber(L, 4);
           lua_rawseti(L, -2, i+1);
       }

       return 1;
}
//----------------------------------------------------------------------LOCAL UTIL
static int getCLError(lua_State * L)
{
    lua_pushnumber(L, err);
    return 1;
}
/*

*/
//----------------------------------------------------------------------QUERYING PLATFORM
static int getPlatformIDs(lua_State *L)
{
    int num_of_platforms = luaL_checkint(L, 1);
    cl_platform_id * platforms = (cl_platform_id *) malloc(num_of_platforms * sizeof(cl_platform_id));
    cl_uint num_platforms_ret;
	err = clGetPlatformIDs(num_of_platforms,
                           platforms,
                           &num_platforms_ret
                           );

	if(err != CL_SUCCESS)
	    lua_pushnil(L);
	else
	{
        lua_newtable(L);
        for(unsigned int i = 0; i < num_platforms_ret; i++)
        {
            lua_pushlightuserdata(L, platforms[i]);
            lua_rawseti(L, -2, i+1);
        }
	}
	free(platforms);
	return 1;
}

static int getPlatformInfo(lua_State *L)
{
    cl_platform_info info;
    size_t param_value_size_ret;
    size_t param_value_size = (size_t) luaL_checkint(L, 3);
    char * param_value = (char *) malloc(sizeof(char) * param_value_size);
    info = get_enum(L, 2);
    err = clGetPlatformInfo((cl_platform_id) lua_touserdata(L, 1),
                            info,
                            param_value_size,
                            param_value,
                            &param_value_size_ret);
    if(err != CL_SUCCESS)
        lua_pushnil(L);
    else
        lua_pushstring(L, param_value);
    free(param_value);
    return 1;
}
//----------------------------------------------------------------------QUERYING DEVICES
static int getDeviceIDs(lua_State *L)
{
    unsigned int i;
    cl_device_type device_type;
    cl_uint num_devices_ret;
    device_type = get_enum(L, 2);
    cl_uint num_of_devices = (cl_uint) luaL_checkint(L, 3);
    cl_device_id * devices = (cl_device_id *) malloc(sizeof(cl_device_id) * num_of_devices);


    err = clGetDeviceIDs((cl_platform_id) lua_touserdata(L, 1),
                         device_type,
                         num_of_devices,
                         devices,
                         &num_devices_ret
                         );
    if(err != CL_SUCCESS)
	    lua_pushnil(L);
	else
	{
        lua_newtable(L);
        for(i = 0; i < num_devices_ret; i++)
        {
            lua_pushlightuserdata(L, devices[i]);
            lua_rawseti(L, -2, i+1);
        }
	}
	free(devices);
	return 1;
}

static int getDeviceInfo(lua_State *L)
{
    int i;
    char *         param_value1 = NULL;
    cl_platform_id param_value2 = 0;
    size_t *       param_value3 = NULL;
    cl_ulong       param_value4 = 0;
    size_t param_value_size;
    size_t param_value_size_ret;

    cl_device_info param_type = get_enum(L, 2);

    switch(param_type)
    {
        case CL_DEVICE_TYPE                             :   // cl_device_type
        case CL_DEVICE_VENDOR_ID                        :   // cl_uint
        case CL_DEVICE_MAX_COMPUTE_UNITS                :
        case CL_DEVICE_MAX_WORK_ITEM_DIMENSIONS         :
        case CL_DEVICE_PREFERRED_VECTOR_WIDTH_CHAR      :
        case CL_DEVICE_PREFERRED_VECTOR_WIDTH_SHORT     :
        case CL_DEVICE_PREFERRED_VECTOR_WIDTH_INT       :
        case CL_DEVICE_PREFERRED_VECTOR_WIDTH_LONG      :
        case CL_DEVICE_PREFERRED_VECTOR_WIDTH_FLOAT     :
        case CL_DEVICE_PREFERRED_VECTOR_WIDTH_DOUBLE    :
        case CL_DEVICE_MAX_CLOCK_FREQUENCY              :
        case CL_DEVICE_ADDRESS_BITS                     :
        case CL_DEVICE_MAX_READ_IMAGE_ARGS              :
        case CL_DEVICE_MAX_WRITE_IMAGE_ARGS             :
        case CL_DEVICE_MAX_SAMPLERS                     :
        case CL_DEVICE_MEM_BASE_ADDR_ALIGN              :
        case CL_DEVICE_MIN_DATA_TYPE_ALIGN_SIZE         :
        case CL_DEVICE_GLOBAL_MEM_CACHELINE_SIZE        :
        case CL_DEVICE_MAX_CONSTANT_ARGS                :
        case CL_DEVICE_MAX_WORK_GROUP_SIZE              :   // size_t
        case CL_DEVICE_IMAGE2D_MAX_WIDTH                :
        case CL_DEVICE_IMAGE2D_MAX_HEIGHT               :
        case CL_DEVICE_IMAGE3D_MAX_WIDTH                :
        case CL_DEVICE_IMAGE3D_MAX_HEIGHT               :
        case CL_DEVICE_IMAGE3D_MAX_DEPTH                :
        case CL_DEVICE_MAX_PARAMETER_SIZE               :
        case CL_DEVICE_PROFILING_TIMER_RESOLUTION       :
        case CL_DEVICE_MAX_MEM_ALLOC_SIZE               :   // cl_ulong
        case CL_DEVICE_GLOBAL_MEM_CACHE_SIZE            :
        case CL_DEVICE_GLOBAL_MEM_SIZE                  :
        case CL_DEVICE_MAX_CONSTANT_BUFFER_SIZE         :
        case CL_DEVICE_LOCAL_MEM_SIZE                   :
        case CL_DEVICE_IMAGE_SUPPORT                    :   // cl_bool
        case CL_DEVICE_ERROR_CORRECTION_SUPPORT         :
        case CL_DEVICE_ENDIAN_LITTLE                    :
        case CL_DEVICE_AVAILABLE                        :
        case CL_DEVICE_COMPILER_AVAILABLE               :
        case CL_DEVICE_SINGLE_FP_CONFIG                 :   // cl_device_fp_config
        case CL_DEVICE_GLOBAL_MEM_CACHE_TYPE            :   // cl_device_mem_cache_type
        case CL_DEVICE_LOCAL_MEM_TYPE                   :   // cl_device_local_mem_type
        case CL_DEVICE_EXECUTION_CAPABILITIES           :   // cl_device_exec_capabilities
        case CL_DEVICE_QUEUE_PROPERTIES                 :   // cl_command_queue_properties
            err = clGetDeviceInfo((cl_device_id) lua_touserdata(L, 1),
                                  param_type,
                                  sizeof(cl_ulong),
                                  (void *) &param_value4,
                                  &param_value_size_ret
                                  );
            if(err != CL_SUCCESS)
                lua_pushnil(L);
            else
                lua_pushnumber(L, param_value4);
            return 1;

        case CL_DEVICE_MAX_WORK_ITEM_SIZES              :   // size_t[]
            param_value_size = luaL_checkint(L, 3);
            param_value3 = (size_t *) malloc(sizeof(size_t) * param_value_size);
            err = clGetDeviceInfo((cl_device_id) lua_touserdata(L, 1),
                                  param_type,
                                  param_value_size * sizeof(size_t),
                                  (void *) param_value3,
                                  &param_value_size_ret
                                  );
            if(err != CL_SUCCESS)
                lua_pushnil(L);
            else lua_pushnumber(L, param_value_size);
                lua_newtable(L);
                for(i = 0; i < param_value_size; i++)
                {
                    lua_pushnumber(L, param_value3[i]);
                    lua_rawseti(L, -2, i+1);
                }
            free(param_value3);
            return 1;

        case CL_DEVICE_PLATFORM                         :   // cl_platform_id
            err = clGetDeviceInfo((cl_device_id) lua_touserdata(L, 1),
                                  param_type,
                                  sizeof(cl_platform_id),
                                  (void *) &param_value2,
                                  &param_value_size_ret
                                  );
            if(err != CL_SUCCESS)
                lua_pushnil(L);
            else
                lua_pushlightuserdata(L, param_value2);
            return 1;

        case CL_DEVICE_NAME                             :   // char[]
        case CL_DEVICE_VENDOR                           :
        case CL_DRIVER_VERSION                          :
        case CL_DEVICE_PROFILE                          :
        case CL_DEVICE_VERSION                          :
        case CL_DEVICE_EXTENSIONS                       :
            param_value_size = luaL_checkint(L, 3);
            param_value1 = (char *) malloc(sizeof(char) * param_value_size);
            err = clGetDeviceInfo((cl_device_id) lua_touserdata(L, 1),
                                  param_type,
                                  param_value_size,
                                  (void *) param_value1,
                                  &param_value_size_ret
                                  );
            if(err != CL_SUCCESS)
                lua_pushnil(L);
            else
                lua_pushstring(L, (const char *) param_value1);
            free(param_value1);
            return 1;

        default                                         :
            lua_pushnil(L);
            return 1;
    }
}
//--------------------------------------------------------------------CONTEXT
static int createContext(lua_State * L)
{
    int i;
    size_t num_properties = lua_objlen(L, 1);
    size_t num_devices = lua_objlen(L, 2);
    cl_context_properties * properties;
    cl_device_id * devices;

    if(num_properties % 2 == 0) num_properties++;
    properties = (cl_context_properties *) malloc(num_properties * sizeof(cl_context_properties));

    for(i = 0; i < num_properties - 1; i++)
    {
        lua_rawgeti(L, 1, i+1);
        if(i % 2 == 0)
            properties[i] = (cl_context_properties) lua_tonumber(L, -1);
        else
            properties[i] = (cl_context_properties)(cl_platform_id) lua_touserdata(L, -1);

    }
    properties[i] = 0;

    devices = (cl_device_id *) malloc(num_devices * sizeof(cl_device_id));
    for(i = 0; i < num_devices; i++)
    {
        lua_rawgeti(L, 2, i+1);
        devices[i] = (cl_device_id) lua_touserdata(L, -1);
    }

    cl_context context = clCreateContext(properties,
                                         num_devices,
                                         devices,
                                         NULL,
                                         NULL,
                                         &err
                                         );
    if(err != CL_SUCCESS)
        lua_pushnil(L);
    else
        lua_pushlightuserdata(L, context);
    free(devices);
    return 1;
}

static int retainContext(lua_State * L)
{
    err = clRetainContext((cl_context)lua_touserdata(L, 1));
    return 0;
}

static int releaseContext(lua_State * L)
{
    err = clReleaseContext((cl_context)lua_touserdata(L, 1));
    return 0;
}
//----------------------------------------------------------------COMMAND QUEUES
static int createCommandQueue(lua_State * L)
{
    cl_command_queue command_queue = clCreateCommandQueue((cl_context)lua_touserdata(L, 1),
                                                          (cl_device_id) lua_touserdata(L, 2),
                                                          lua_tonumber(L, 3),
                                                          &err
                                                          );
    if(err != CL_SUCCESS)
        lua_pushnil(L);
    else
        lua_pushlightuserdata(L, command_queue);

    return 1;
}

static int retainCommandQueue(lua_State * L)
{
    err = clRetainCommandQueue((cl_command_queue) lua_touserdata(L, 1));
    return 0;
}

static int releaseCommandQueue(lua_State * L)
{
    err = clReleaseCommandQueue((cl_command_queue) lua_touserdata(L, 1));
    return 0;
}
//----------------------------------------------------------------BUFFER OBJECTS
static int BufferUINT(lua_State * L)
{
    cl_mem buffer;
    int i, len;
    cl_uint * num_buffer = NULL;
    cl_mem_flags flags = get_enum(L, 2);



    if((flags & CL_MEM_USE_HOST_PTR) || (flags & CL_MEM_COPY_HOST_PTR))
    {
        len = lua_tonumber(L, 3);
        //printf("%d\n", lua_checkstack(L, len));
        num_buffer = (cl_uint *) malloc(len*sizeof(cl_uint));
        for(i = 0; i < len; i++)
        {
            lua_rawgeti(L, 4, i+1);
            num_buffer[i] = (unsigned int) lua_tonumber(L, -1);
            lua_remove(L, -1);
            //printf("%u : %d\n", num_buffer[i], i); fflush((stdout));
        }

        buffer = clCreateBuffer((cl_context) lua_touserdata(L, 1),
                                flags,
                                len * sizeof(cl_uint),
                                num_buffer,
                                &err
                                );
    }
    else
    {
        buffer = clCreateBuffer((cl_context) lua_touserdata(L, 1),
                                flags,
                                (size_t) lua_tonumber(L, 3) * sizeof(cl_uint),
                                NULL,
                                &err
                                );
    }

    if(err != CL_SUCCESS)
        lua_pushnil(L);
    else
        lua_pushlightuserdata(L, buffer);
    return 1;
}
static int createBuffer(lua_State * L)
{
    cl_mem buffer;
    int len, i;
    const char * c;
    unsigned int * num_buffer = NULL;
    char * char_buffer = NULL;
    cl_mem_flags flags = get_enum(L, 2);


    if((flags & CL_MEM_USE_HOST_PTR) || (flags & CL_MEM_COPY_HOST_PTR))
    {
        len = lua_tonumber(L, 3);

        if(lua_tonumber(L, 4) == sizeof(LUA_NUMBER))
        {
            num_buffer = (unsigned int *) malloc(len*sizeof(unsigned int));
            for(i = 0; i < len; i++)
            {
                lua_rawgeti(L, 5, i+1);
                num_buffer[i] = (unsigned int) lua_tonumber(L, -1);
                printf("%u\n", num_buffer[i]);
            }

            buffer = clCreateBuffer((cl_context) lua_touserdata(L, 1),
                                flags,
                                lua_tonumber(L, 3) * sizeof(unsigned int),
                                num_buffer,
                                &err
                                );
        }
        else
        {
            char_buffer = (char *) malloc(len*sizeof(char));
            for(i = 0; i < len; i++)
            {
                lua_rawgeti(L, 5, i+1);
                c = lua_tostring(L, -1);
                char_buffer[i] = *c;
            }

            buffer = clCreateBuffer((cl_context) lua_touserdata(L, 1),
                                flags,
                                lua_tonumber(L, 3) * sizeof(LUA_NUMBER),
                                &char_buffer,
                                &err
                                );
        }
    }
    else
    {
        buffer = clCreateBuffer((cl_context) lua_touserdata(L, 1),
                                flags,
                                lua_tonumber(L, 3),
                                NULL,
                                &err
                                );
    }

    if(err != CL_SUCCESS)
        lua_pushnil(L);
    else
        lua_pushlightuserdata(L, buffer);
    return 1;
}
static int releaseMemObject(lua_State * L)
{
    err = clReleaseMemObject((cl_mem) lua_touserdata(L, 1));
    return 0;
}
//----------------------------------------------------------------MEMORY OBJECTS
static int enqueueMapBuffer(lua_State * L)
{
    cl_uint * ptr;
    unsigned int count = lua_tonumber(L, 7);
    ptr = (cl_uint *)clEnqueueMapBuffer((cl_command_queue) lua_touserdata(L, 1),
                                        (cl_mem) lua_touserdata(L, 2),
                                        (cl_bool) lua_tonumber(L, 3),
                                        (cl_map_flags) lua_tonumber(L, 4),
                                        (size_t) lua_tonumber(L, 5),
                                        (size_t) lua_tonumber(L, 6) * (size_t) lua_tonumber(L, 7),
                                        0, NULL, NULL,
                                        &err
                                        );
    lua_newtable(L);
    for(unsigned int i = 0; i < count; i++)
    {
        lua_pushnumber(L, ptr[i]);
        lua_rawseti(L, -2, i+1);
    }
    return 1;
}

static int enqueueWriteBuffer(lua_State * L)
{
    int i;
    cl_uint * buff = NULL;
    buff = (cl_uint *) malloc(sizeof(cl_uint) * (size_t)lua_tonumber(L, 6));

    for(i = 0; i < lua_tonumber(L, 6); i++)
    {
        lua_rawgeti(L, 7, i+1);
        buff[i] = (unsigned int) lua_tonumber(L, -1);
        lua_remove(L, -1);
        //printf("%u : %d\n", num_buffer[i], i); fflush((stdout));
    }

    err = clEnqueueWriteBuffer((cl_command_queue) lua_touserdata(L, 1),
                               (cl_mem) lua_touserdata(L, 2),
                               (cl_bool) lua_tonumber(L, 3),
                               (size_t) lua_tonumber(L, 4),
                               (size_t) lua_tonumber(L, 5) * (size_t) lua_tonumber(L, 6),
                               buff,
                               0, NULL, NULL
                               );
}
//----------------------------------------------------------------PROGRAM OBJECTS
static int createProgramWithSource(lua_State * L)
{
    const char * source = lua_tostring(L, 2);
    cl_program program = clCreateProgramWithSource((cl_context) lua_touserdata(L, 1),
                                                   1,
                                                   &source,
                                                   NULL,
                                                   &err
                                                   );
    if(err != CL_SUCCESS)
        lua_pushnil(L);
    else
        lua_pushlightuserdata(L, program);
    return 1;
}

static int buildProgram(lua_State * L)
{
    size_t num = lua_objlen(L, 2);
    cl_device_id * devices = (cl_device_id *) malloc(num * sizeof(cl_device_id));

    for(unsigned int i = 0; i < num; i++)
    {
        lua_rawgeti(L, 2, i+1);
        devices[i] = (cl_device_id) lua_touserdata(L, -1);
    }

    err = clBuildProgram((cl_program) lua_touserdata(L, 1),
                                num,
                                devices,
                                NULL, NULL, NULL
                                );
    free(devices);
    return 0;
}
static int releaseProgram(lua_State * L)
{
    err = clReleaseProgram((cl_program) lua_touserdata(L, 1));
    return 0;
}
//----------------------------------------------------------------PROGRAM OBJECT QUERIES
static int getProgramBuildInfo(lua_State * L)
{
    char pr[5000];
    err = clGetProgramBuildInfo((cl_program) lua_touserdata(L, 1),
                                       (cl_device_id) lua_touserdata(L, 2),
                                       lua_tonumber(L, 3),
                                       5000,
                                       pr,
                                       NULL
                                       );
    if(err != CL_SUCCESS)
        lua_pushnil(L);
    else
        lua_pushstring(L, pr);
    return 1;
}
//----------------------------------------------------------------KERNEL OBJECTS
static int createKernel(lua_State * L)
{
    cl_kernel kernel = clCreateKernel((cl_program) lua_touserdata(L, 1),
                                      (const char *) lua_tostring(L, 2),
                                      &err
                                      );
    if(err != CL_SUCCESS)
        lua_pushnil(L);
    else
        lua_pushlightuserdata(L, kernel);
    return 1;
}

static int setKernelArg(lua_State * L)
{
    void * arg_value = lua_touserdata(L, 3);
    err = clSetKernelArg((cl_kernel) lua_touserdata(L, 1),
                                (cl_uint) lua_tonumber(L, 2),
                                sizeof(arg_value),
                                &arg_value
                                );
    return 0;
}
static int releaseKernel(lua_State * L)
{
    err = clReleaseKernel((cl_kernel) lua_touserdata(L, 1));
    return 0;
}
//----------------------------------------------------------------EXECUTING KERNELS
static int enqueueNDRangeKernel(lua_State * L)
{
    const size_t global_work_size = lua_tonumber(L, 4);
    //const size_t local_work_size = lua_tonumber(L, 5);
    err = clEnqueueNDRangeKernel((cl_command_queue) lua_touserdata(L, 1),
                                        (cl_kernel) lua_touserdata(L, 2),
                                        (cl_uint) lua_tonumber(L, 3),
                                        NULL,
                                        &global_work_size,
                                        NULL,
                                        0, NULL, NULL
                                        );
    return 0;
}

//----------------------------------------------------------------FLUSH AND FINISH
static int finish(lua_State * L)
{
    err = clFinish((cl_command_queue) lua_touserdata(L, 1));
    return 0;
}
//---------------------------------------------------------
static const struct luaL_Reg LuaCL [] = {
    #ifdef _WIN32
    {"Timer"                        , performaceTimer},
    #endif
    {"GetPlatformIDs"               , getPlatformIDs},
    {"GetPlatformInfo"              , getPlatformInfo},
    {"GetDeviceIDs"                 , getDeviceIDs},
    {"GetDeviceInfo"                , getDeviceInfo},
    {"CreateContext"                , createContext},
    {"RetainContext"                , retainContext},
    {"ReleaseContext"               , releaseContext},
    {"CreateCommandQueue"           , createCommandQueue},
    {"RetainCommandQueue"           , retainCommandQueue},
    {"ReleaseCommandQueue"          , releaseCommandQueue},
    {"CreateBuffer"                 , createBuffer},
    {"BufferUINT"                   , BufferUINT},
    {"CreateProgramWithSource"      , createProgramWithSource},
    {"BuildProgram"                 , buildProgram},
    {"GetProgramBuildInfo"          , getProgramBuildInfo},
    {"CreateKernel"                 , createKernel},
    {"SetKernelArg"                 , setKernelArg},
    {"EnqueueNDRangeKernel"         , enqueueNDRangeKernel},
    {"Finish"                       , finish},
    {"EnqueueMapBuffer"             , enqueueMapBuffer},
    {"EnqueueWriteBuffer"           , enqueueWriteBuffer},
    {"ReleaseKernel"                , releaseKernel},
    {"ReleaseProgram"               , releaseProgram},
    {"ReleaseMemObject"             , releaseMemObject},
    {"GetCLError"                   , getCLError},
        {"Deb1"                , deb1},
        {"Deb2"                , deb2},
    {NULL                           , NULL}
};
int get_enum_val(const char * str, int n)
{
    int i = 0;

    while(cl_const[i].cl != 0)
    {
        if(strncmp(str, cl_const[i].cl, n) == 0 && cl_const[i].cl[n] == 0)
            return cl_const[i].value;
        i++;
    }
  return -1;
}
int get_enum(lua_State * L, int position)
{
    const char * str;
    int retval = 0;
    int enum_value;
    int length = 0;
    int i;

    if(lua_isnumber(L, position))
        return lua_tonumber(L, position);

    str = luaL_checkstring(L, position);

    length = strlen(str);

    for(i = 0; i <= length; i++)
    {
        if((str[i] == ' ') || (str[i] == ',') || (str[i] == '\0'))
        {
            if(i != 0)
            {
                if((enum_value = get_enum_val(str, i)) == -1)
                {
                   return -1;
                }

                else
                    retval |= enum_value;

				str += i;
				length -= i;
				i = -1;
				if(i == length) break;
            }
            else
			{
				str++;
                i = -1;
				length--;
			}
        }
    }
    return retval;
}

static int luacl_register_enum(lua_State * L)
{
    int i;
    for (i = 0; ; i++)
    {
        if(cl_const[i].cl == NULL) return 1;
        lua_pushnumber(L, cl_const[i].value);
        lua_setfield(L, -2, cl_const[i].cl);
    }
}
/*
** Open library
*/
DLL_EXPORT int luaopen_LuaCl (lua_State *L) {
  luaL_register(L, "cl", LuaCL);
  luacl_register_enum(L);
  return 1;
}

#ifdef __cplusplus
}
#endif
