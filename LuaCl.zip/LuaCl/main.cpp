#ifndef BUILD_DLL
#define BUILD_DLL
#endif

#include "main.h"

#ifdef __cplusplus
extern "C"
{
#endif
//----------------------------------------------------------------------
#ifdef _WIN32
static int performaceTime(lua_State * L)
{
    lua_pushnumber(L, GetTickCount());
    return 1;
}
#endif
size_t get_events(lua_State ** L, cl_event * in_event_list, int pos)
{

    size_t size, i;
    if(lua_istable(*L, pos))
    {
        if((size = lua_objlen(*L, pos)) > 0)
        {
            in_event_list = (cl_event *) malloc(size * sizeof(cl_event));
            for(i = 0; i < size; i++)
            {
                lua_rawgeti(*L, pos, i+1);
                in_event_list[i] = (cl_event) lua_touserdata(*L, -1);
                lua_remove(*L, -1);
            }
            return size;
        }
    }
    return 0;
}
void enqueue_buffer_operation(lua_State ** L, TYPE type, void * buffer, size_t buff_len, size_t size, cl_event * event, cl_int mode /*0 - read; 1 - write */)
{
    unsigned int    i;
    cl_uint         events_in_list = 0;
    cl_event *      event_list = NULL;

    events_in_list = get_events(L, event_list, 6);

    if(mode == 1) // write
    {
        for(i = 0; i < buff_len; i++)
        {
            lua_rawgeti(*L, 5, i+1);
            switch(type)
            {
                case type_cl_char   : *((cl_char    *) buffer + i) = (cl_char) lua_tonumber(*L, -1); break;
                case type_cl_uchar  : *((cl_uchar   *) buffer + i) = (cl_uchar) lua_tonumber(*L, -1); break;
                case type_cl_short  : *((cl_short   *) buffer + i) = (cl_short) lua_tonumber(*L, -1); break;
                case type_cl_ushort : *((cl_ushort  *) buffer + i) = (cl_ushort) lua_tonumber(*L, -1); break;
                case type_cl_int    : *((cl_int     *) buffer + i) = (cl_int) lua_tonumber(*L, -1); break;
                case type_cl_uint   : *((cl_uint    *) buffer + i) = (cl_uint) lua_tonumber(*L, -1); break;
                case type_cl_long   : *((cl_long    *) buffer + i) = (cl_long) lua_tonumber(*L, -1); break;
                case type_cl_ulong  : *((cl_ulong   *) buffer + i) = (cl_ulong) lua_tonumber(*L, -1); break;
                case type_cl_half   : *((cl_half    *) buffer + i) = (cl_half) lua_tonumber(*L, -1); break;
            }
            lua_remove(*L, -1);
        }
        err = clEnqueueWriteBuffer((cl_command_queue) lua_touserdata(*L, 1), (cl_mem) lua_touserdata(*L, 2), (cl_bool) lua_tonumber(*L, 3),
                                   (size_t) lua_tonumber(*L, 4), buff_len * size, buffer, events_in_list, event_list, event);
    }
    else if(mode == 0) // read
    {
        err = clEnqueueReadBuffer((cl_command_queue) lua_touserdata(*L, 1), (cl_mem) lua_touserdata(*L, 2), (cl_bool) lua_tonumber(*L, 3),
                                   (size_t) lua_tonumber(*L, 4), buff_len * size, buffer, events_in_list, event_list, event);

        if(err != CL_SUCCESS)
        {
            lua_pushnil(*L);
            return;
        }

        lua_newtable(*L);
        for(i = 0; i < buff_len; i++)
        {
            switch(type)
            {
                case type_cl_char   : lua_pushnumber(*L, *((cl_char    *) buffer + i)); break;
                case type_cl_uchar  : lua_pushnumber(*L, *((cl_uchar   *) buffer + i)); break;
                case type_cl_short  : lua_pushnumber(*L, *((cl_short   *) buffer + i)); break;
                case type_cl_ushort : lua_pushnumber(*L, *((cl_ushort  *) buffer + i)); break;
                case type_cl_int    : lua_pushnumber(*L, *((cl_int     *) buffer + i)); break;
                case type_cl_uint   : lua_pushnumber(*L, *((cl_uint    *) buffer + i)); break;
                case type_cl_long   : lua_pushnumber(*L, *((cl_long    *) buffer + i)); break;
                case type_cl_ulong  : lua_pushnumber(*L, *((cl_ulong   *) buffer + i)); break;
                case type_cl_half   : lua_pushnumber(*L, *((cl_half    *) buffer + i)); break;
            }
            lua_rawseti(*L, -2, i+1);
        }
    }
}
static int getCLError(lua_State * L)
{
    lua_pushnumber(L, err);
    return 1;
}
//----------------------------------------------------------------------
static int getPlatformIDs(lua_State *L)
{
    unsigned int        i;
    cl_platform_id *    platforms;
    cl_uint             num_platforms_ret;

    if(lua_gettop(L) != 0)
        num_platforms_ret = luaL_checkint(L, 1);
    else
        clGetPlatformIDs(0, NULL, &num_platforms_ret);

    platforms = (cl_platform_id *) malloc(num_platforms_ret * sizeof(cl_platform_id));
	err = clGetPlatformIDs(num_platforms_ret, platforms, &num_platforms_ret);

	if(err != CL_SUCCESS)
	    lua_pushnil(L);
	else
	{
        lua_newtable(L);
        for(i = 0; i < num_platforms_ret; i++)
        {
            lua_pushlightuserdata(L, platforms[i]);
            lua_rawseti(L, -2, i+1);
        }
	}
	free(platforms);
	return 1;
}
//----------------------------------------------------------------------
static int getPlatformInfo(lua_State *L)
{
    cl_platform_info    info;
    size_t              param_value_size_ret;
    char *              param_value;

    info = (cl_platform_info) get_enum(L, 2);

    clGetPlatformInfo((cl_platform_id) lua_touserdata(L, 1), info, 0, NULL, &param_value_size_ret);

    param_value = (char *) malloc(sizeof(char) * param_value_size_ret);
    err = clGetPlatformInfo((cl_platform_id) lua_touserdata(L, 1), info, param_value_size_ret, param_value, NULL);

    (err != CL_SUCCESS) ? lua_pushnil(L) : lua_pushstring(L, param_value);
    free(param_value);
    return 1;
}
//----------------------------------------------------------------------
static int getDeviceIDs(lua_State *L)
{
    unsigned int    i;
    cl_uint         num_devices_ret;
    cl_uint         num_devices;
    cl_device_id *  devices;
    cl_device_type  device_type = get_enum(L, 2);

    if(lua_gettop(L) >= 3)
    {
        num_devices = (cl_uint) luaL_checkint(L, 3);
        devices = (cl_device_id *) malloc(sizeof(cl_device_id) * num_devices);
        err = clGetDeviceIDs((cl_platform_id) lua_touserdata(L, 1), device_type, num_devices, devices, &num_devices_ret);
        num_devices_ret = (num_devices_ret > num_devices) ? num_devices : num_devices_ret;
    }

    else
    {
        clGetDeviceIDs((cl_platform_id) lua_touserdata(L, 1), device_type, 0, NULL, &num_devices_ret);
        devices = (cl_device_id *) malloc(sizeof(cl_device_id) * num_devices_ret);
        err = clGetDeviceIDs((cl_platform_id) lua_touserdata(L, 1), device_type, num_devices_ret, devices, &num_devices_ret);
    }

    if(err != CL_SUCCESS)
	    lua_pushnil(L);
	else
	{
        lua_newtable(L);
        for(i = 0; i < num_devices_ret; i++)
        {
            lua_pushlightuserdata(L, devices[i]);
            lua_rawseti(L, -2, i+1);
        }
	}
	free(devices);
	return 1;
}

static int getDeviceInfo(lua_State *L)
{
    unsigned int    i;
    char *          param_value_char;
    cl_platform_id  param_value_platform = 0;
    size_t *        param_value_sizet = NULL;
    cl_ulong        param_value_ulong = 0;
    size_t          param_value_size_ret;

    cl_device_info param_type = get_enum(L, 2);

    clGetDeviceInfo((cl_device_id) lua_touserdata(L, 1), param_type, 0, NULL, &param_value_size_ret);

    switch(param_type)
    {
        case CL_DEVICE_TYPE                             :   // cl_device_type
        case CL_DEVICE_VENDOR_ID                        :   // cl_uint
        case CL_DEVICE_MAX_COMPUTE_UNITS                :
        case CL_DEVICE_MAX_WORK_ITEM_DIMENSIONS         :
        case CL_DEVICE_PREFERRED_VECTOR_WIDTH_CHAR      :
        case CL_DEVICE_PREFERRED_VECTOR_WIDTH_SHORT     :
        case CL_DEVICE_PREFERRED_VECTOR_WIDTH_INT       :
        case CL_DEVICE_PREFERRED_VECTOR_WIDTH_LONG      :
        case CL_DEVICE_PREFERRED_VECTOR_WIDTH_FLOAT     :
        case CL_DEVICE_PREFERRED_VECTOR_WIDTH_DOUBLE    :
        case CL_DEVICE_MAX_CLOCK_FREQUENCY              :
        case CL_DEVICE_ADDRESS_BITS                     :
        case CL_DEVICE_MAX_READ_IMAGE_ARGS              :
        case CL_DEVICE_MAX_WRITE_IMAGE_ARGS             :
        case CL_DEVICE_MAX_SAMPLERS                     :
        case CL_DEVICE_MEM_BASE_ADDR_ALIGN              :
        case CL_DEVICE_MIN_DATA_TYPE_ALIGN_SIZE         :
        case CL_DEVICE_GLOBAL_MEM_CACHELINE_SIZE        :
        case CL_DEVICE_MAX_CONSTANT_ARGS                :
        case CL_DEVICE_MAX_WORK_GROUP_SIZE              :   // size_t
        case CL_DEVICE_IMAGE2D_MAX_WIDTH                :
        case CL_DEVICE_IMAGE2D_MAX_HEIGHT               :
        case CL_DEVICE_IMAGE3D_MAX_WIDTH                :
        case CL_DEVICE_IMAGE3D_MAX_HEIGHT               :
        case CL_DEVICE_IMAGE3D_MAX_DEPTH                :
        case CL_DEVICE_MAX_PARAMETER_SIZE               :
        case CL_DEVICE_PROFILING_TIMER_RESOLUTION       :
        case CL_DEVICE_MAX_MEM_ALLOC_SIZE               :   // cl_ulong
        case CL_DEVICE_GLOBAL_MEM_CACHE_SIZE            :
        case CL_DEVICE_GLOBAL_MEM_SIZE                  :
        case CL_DEVICE_MAX_CONSTANT_BUFFER_SIZE         :
        case CL_DEVICE_LOCAL_MEM_SIZE                   :
        case CL_DEVICE_IMAGE_SUPPORT                    :   // cl_bool
        case CL_DEVICE_ERROR_CORRECTION_SUPPORT         :
        case CL_DEVICE_ENDIAN_LITTLE                    :
        case CL_DEVICE_AVAILABLE                        :
        case CL_DEVICE_COMPILER_AVAILABLE               :
        case CL_DEVICE_SINGLE_FP_CONFIG                 :   // cl_device_fp_config
        case CL_DEVICE_GLOBAL_MEM_CACHE_TYPE            :   // cl_device_mem_cache_type
        case CL_DEVICE_LOCAL_MEM_TYPE                   :   // cl_device_local_mem_type
        case CL_DEVICE_EXECUTION_CAPABILITIES           :   // cl_device_exec_capabilities
        case CL_DEVICE_QUEUE_PROPERTIES                 :   // cl_command_queue_properties
            err = clGetDeviceInfo((cl_device_id) lua_touserdata(L, 1), param_type, param_value_size_ret, (void *) &param_value_ulong, NULL);
            (err != CL_SUCCESS) ? lua_pushnil(L) : lua_pushnumber(L, param_value_ulong);
            return 1;
        case CL_DEVICE_MAX_WORK_ITEM_SIZES              :   // size_t[]
            param_value_sizet = (size_t *) malloc(param_value_size_ret);
            err = clGetDeviceInfo((cl_device_id) lua_touserdata(L, 1), param_type, param_value_size_ret, (void *) param_value_sizet, NULL);

            if(err != CL_SUCCESS)
                lua_pushnil(L);
            else
            {
                lua_newtable(L);
                for(i = 0; i < param_value_size_ret/sizeof(size_t); i++)
                {
                    lua_pushnumber(L, param_value_sizet[i]);
                    lua_rawseti(L, -2, i+1);
                }
            }
            free(param_value_sizet);
            return 1;

        case CL_DEVICE_PLATFORM                         :   // cl_platform_id
            err = clGetDeviceInfo((cl_device_id) lua_touserdata(L, 1), param_type, param_value_size_ret, (void *) &param_value_platform, NULL);
            (err != CL_SUCCESS) ? lua_pushnil(L) : lua_pushlightuserdata(L, param_value_platform);
            return 1;
        case CL_DEVICE_NAME                             :   // char[]
        case CL_DEVICE_VENDOR                           :
        case CL_DRIVER_VERSION                          :
        case CL_DEVICE_PROFILE                          :
        case CL_DEVICE_VERSION                          :
        case CL_DEVICE_EXTENSIONS                       :
            param_value_char = (char *) malloc(param_value_size_ret);
            err = clGetDeviceInfo((cl_device_id) lua_touserdata(L, 1), param_type, param_value_size_ret, (void *) param_value_char, NULL);
            (err != CL_SUCCESS) ? lua_pushnil(L) : lua_pushstring(L, (const char *) param_value_char);
            free(param_value_char);
            return 1;
        default                                         :
            lua_pushnil(L);
            return 1;
    }
}
//--------------------------------------------------------------------CONTEXT
static int createContext(lua_State * L)
{
    unsigned int i;
    size_t num_properties = lua_objlen(L, 1);
    size_t num_devices = lua_objlen(L, 2);
    cl_context_properties * properties;
    cl_device_id * devices;

    if(num_properties % 2 == 0) num_properties++;
    properties = (cl_context_properties *) malloc(num_properties * sizeof(cl_context_properties));

    for(i = 0; i < num_properties - 1; i++)
    {
        lua_rawgeti(L, 1, i+1);
        if(i % 2 == 0)
            properties[i] = (cl_context_properties) lua_tonumber(L, -1);
        else
            properties[i] = (cl_context_properties)(cl_platform_id) lua_touserdata(L, -1);
        lua_remove(L, -1);

    }
    properties[i] = 0;

    devices = (cl_device_id *) malloc(num_devices * sizeof(cl_device_id));
    for(i = 0; i < num_devices; i++)
    {
        lua_rawgeti(L, 2, i+1);
        devices[i] = (cl_device_id) lua_touserdata(L, -1);
        lua_remove(L, -1);
    }

    cl_context context = clCreateContext(properties, num_devices, devices, NULL, NULL, &err);

    (err != CL_SUCCESS) ? lua_pushnil(L) : lua_pushlightuserdata(L, context);
    free(devices); free(properties);
    return 1;
}

static int retainContext(lua_State * L)
{
    err = clRetainContext((cl_context)lua_touserdata(L, 1));
    return 0;
}

static int releaseContext(lua_State * L)
{
    err = clReleaseContext((cl_context)lua_touserdata(L, 1));
    return 0;
}
//----------------------------------------------------------------COMMAND QUEUES
static int createCommandQueue(lua_State * L)
{
    cl_command_queue command_queue = clCreateCommandQueue((cl_context)lua_touserdata(L, 1), (cl_device_id) lua_touserdata(L, 2), lua_tonumber(L, 3), &err);
    (err != CL_SUCCESS) ? lua_pushnil(L) : lua_pushlightuserdata(L, command_queue);
    return 1;
}

static int retainCommandQueue(lua_State * L)
{
    err = clRetainCommandQueue((cl_command_queue) lua_touserdata(L, 1));
    return 0;
}

static int releaseCommandQueue(lua_State * L)
{
    err = clReleaseCommandQueue((cl_command_queue) lua_touserdata(L, 1));
    return 0;
}

//----------------------------------------------------------------BUFFER OBJECTS
static int BufferUINT(lua_State * L)
{
    cl_mem buffer;
    int i, len;
    cl_uint * num_buffer = NULL;
    cl_mem_flags flags = get_enum(L, 2);

    if((flags & CL_MEM_USE_HOST_PTR) || (flags & CL_MEM_COPY_HOST_PTR))
    {
        len = lua_tonumber(L, 3);
        num_buffer = (cl_uint *) malloc(len*sizeof(cl_uint));
        for(i = 0; i < len; i++)
        {
            lua_rawgeti(L, 4, i+1);
            num_buffer[i] = (unsigned int) lua_tonumber(L, -1);
            lua_remove(L, -1);
        }

        buffer = clCreateBuffer((cl_context) lua_touserdata(L, 1), flags, len * sizeof(cl_uint), num_buffer, &err);
    }
    else
    {
        buffer = clCreateBuffer((cl_context) lua_touserdata(L, 1), flags, (size_t) lua_tonumber(L, 3) * sizeof(cl_uint), NULL, &err);
    }
    (err != CL_SUCCESS) ? lua_pushnil(L) : lua_pushlightuserdata(L, buffer);
    return 1;
}

static int releaseMemObject(lua_State * L)
{
    err = clReleaseMemObject((cl_mem) lua_touserdata(L, 1));
    return 0;
}
//----------------------------------------------------------------MEMORY OBJECTS
static int enqueueMapBuffer(lua_State * L)
{
    cl_uint * ptr;
    unsigned int count = lua_tonumber(L, 7);
    ptr = (cl_uint *)clEnqueueMapBuffer((cl_command_queue) lua_touserdata(L, 1),
                                        (cl_mem) lua_touserdata(L, 2),
                                        (cl_bool) lua_tonumber(L, 3),
                                        (cl_map_flags) lua_tonumber(L, 4),
                                        (size_t) lua_tonumber(L, 5),
                                        (size_t) lua_tonumber(L, 6) * (size_t) lua_tonumber(L, 7),
                                        0, NULL, NULL,
                                        &err
                                        );
    lua_newtable(L);
    for(unsigned int i = 0; i < count; i++)
    {
        lua_pushnumber(L, ptr[i]);
        lua_rawseti(L, -2, i+1);
    }
    return 1;
}

static int enqueueWriteUINTBuffer(lua_State * L)
{
    cl_event event_ret;
    cl_uint * cl_uint_buffer;
    size_t buff_size = lua_objlen(L, 5);
    cl_uint_buffer = (cl_uint *) malloc((size_t) lua_tonumber(L, 5) * buff_size);

    enqueue_buffer_operation(&L, type_cl_uint, (void *) cl_uint_buffer, buff_size, sizeof(cl_uint), &event_ret, 1);

    (err != CL_SUCCESS) ? lua_pushnil(L) : lua_pushlightuserdata(L, event_ret);
    return 1;
}
static int enqueueReadUINTBuffer(lua_State * L)
{
    cl_event event_ret;
    cl_uint * cl_uint_buffer;
    size_t buff_size = (size_t) lua_tonumber(L, 5);
    cl_uint_buffer = (cl_uint *) malloc(sizeof(cl_uint) * buff_size);

    enqueue_buffer_operation(&L, type_cl_uint, (void *) cl_uint_buffer, buff_size, sizeof(cl_uint), &event_ret, 0);

    return 1;
}
//----------------------------------------------------------------PROGRAM OBJECTS
static int createProgramWithSource(lua_State * L)
{
    const char * source = lua_tostring(L, 2);
    cl_program program = clCreateProgramWithSource((cl_context) lua_touserdata(L, 1),
                                                   1,
                                                   &source,
                                                   NULL,
                                                   &err
                                                   );
    if(err != CL_SUCCESS)
        lua_pushnil(L);
    else
        lua_pushlightuserdata(L, program);
    return 1;
}

static int buildProgram(lua_State * L)
{
    size_t num = lua_objlen(L, 2);
    cl_device_id * devices = (cl_device_id *) malloc(num * sizeof(cl_device_id));

    for(unsigned int i = 0; i < num; i++)
    {
        lua_rawgeti(L, 2, i+1);
        devices[i] = (cl_device_id) lua_touserdata(L, -1);
    }

    err = clBuildProgram((cl_program) lua_touserdata(L, 1),
                                num,
                                devices,
                                NULL, NULL, NULL
                                );
    free(devices);
    return 0;
}
static int releaseProgram(lua_State * L)
{
    err = clReleaseProgram((cl_program) lua_touserdata(L, 1));
    return 0;
}
//----------------------------------------------------------------PROGRAM OBJECT QUERIES
static int getProgramBuildInfo(lua_State * L)
{
    size_t                  size_ret;
    char *                  param_value;
    cl_int                  param_value_status;
    cl_program_build_info   param_name = (cl_program_build_info)  get_enum(L, 2);



    switch(param_name)
    {
        case CL_PROGRAM_BUILD_STATUS    :
            err = clGetProgramBuildInfo((cl_program) lua_touserdata(L, 1), (cl_device_id) lua_touserdata(L, 2), param_name, sizeof(cl_int), &param_value_status, NULL);
            (err != CL_SUCCESS) ? lua_pushnil(L) : lua_pushnumber(L, param_value_status);
        case CL_PROGRAM_BUILD_OPTIONS   :
        case CL_PROGRAM_BUILD_LOG       :
            clGetProgramBuildInfo((cl_program) lua_touserdata(L, 1), (cl_device_id) lua_touserdata(L, 2), param_name, 0, NULL, &size_ret);
            param_value = (char *) malloc(sizeof(char) * size_ret);
            err = clGetProgramBuildInfo((cl_program) lua_touserdata(L, 1), (cl_device_id) lua_touserdata(L, 2), param_name, size_ret, param_value, NULL);
            (err != CL_SUCCESS) ? lua_pushnil(L) : lua_pushstring(L, param_value);
        default                         :
            lua_pushnil(L);
            return 1;
    }
    return 0;
}
//----------------------------------------------------------------KERNEL OBJECTS
static int createKernel(lua_State * L)
{
    cl_kernel kernel = clCreateKernel((cl_program) lua_touserdata(L, 1), (const char *) lua_tostring(L, 2), &err);
    (err != CL_SUCCESS) ? lua_pushnil(L) : lua_pushlightuserdata(L, kernel);
    return 1;
}

static int setKernelArg(lua_State * L)
{
    void * arg_value = lua_touserdata(L, 3);
    err = clSetKernelArg((cl_kernel) lua_touserdata(L, 1), (cl_uint) lua_tonumber(L, 2), sizeof(arg_value), &arg_value);
    return 0;
}

static int releaseKernel(lua_State * L)
{
    err = clReleaseKernel((cl_kernel) lua_touserdata(L, 1));
    return 0;
}
//----------------------------------------------------------------EXECUTING KERNELS
static int enqueueNDRangeKernel(lua_State * L)
{
    const size_t global_work_size = lua_tonumber(L, 4);
    //const size_t local_work_size = lua_tonumber(L, 5);
    err = clEnqueueNDRangeKernel((cl_command_queue) lua_touserdata(L, 1),
                                        (cl_kernel) lua_touserdata(L, 2),
                                        (cl_uint) lua_tonumber(L, 3),
                                        NULL,
                                        &global_work_size,
                                        NULL,
                                        0, NULL, NULL
                                        );
    return 0;
}

//----------------------------------------------------------------FLUSH AND FINISH
static int finish(lua_State * L)
{
    err = clFinish((cl_command_queue) lua_touserdata(L, 1));
    return 0;
}
//----------------------------------------------------------------

static int getContextInfo(lua_State * L)
{
    unsigned int i;
    size_t size_ret;
    cl_uint param_value_uint;
    cl_device_id * param_value_dev;
    //cl_context_properties * param_value_props;                                                                    // !

    cl_context_info param_name = get_enum(L, 2);

    switch(param_name)
    {
        case CL_CONTEXT_REFERENCE_COUNT : //cl_uint
            err = clGetContextInfo((cl_context) lua_touserdata(L, 1),
                                   param_name,
                                   (size_t) sizeof(param_value_uint),
                                   &param_value_uint,
                                   &size_ret
                                   );
            if(err != CL_SUCCESS)
                lua_pushnil(L);
            else
                lua_pushnumber(L, param_value_uint);
            return 1;

        case CL_CONTEXT_DEVICES         : // cl_device_id[]
            clGetContextInfo((cl_context) lua_touserdata(L, 1), param_name, 0, NULL, &size_ret);
            param_value_dev = (cl_device_id *) malloc(size_ret);
            err = clGetContextInfo((cl_context) lua_touserdata(L, 1), param_name,size_ret, param_value_dev, NULL);
            if(err != CL_SUCCESS)
                lua_pushnil(L);
            else
            {
                lua_newtable(L);
                for(i = 0; i < size_ret/sizeof(cl_device_id); i++)
                {
                    lua_pushlightuserdata(L, param_value_dev[i]);
                    lua_rawseti(L, -2, i+1);
                }
            }
            //free(param_value_dev);
            return 1;
        case CL_CONTEXT_PROPERTIES      : // cl_context_properties[]
            clGetContextInfo((cl_context) lua_touserdata(L, 1), param_name, 0, NULL, &size_ret);
            break;

        default :
            lua_pushnil(L);
            return 1;
    }
    return 0;
}
//----------------------------------------------------------------
static int getCommandQueueInfo(lua_State * L)
{
    cl_context                  param_value_context;
    cl_device_id                param_value_device;
    cl_uint                     param_value_ref_count;
    cl_command_queue_properties param_value_props;

    cl_command_queue_info param_name = (cl_command_queue_info) get_enum(L, 2);

    switch(param_name)
    {
        case CL_QUEUE_CONTEXT           : // cl_context
            err = clGetCommandQueueInfo((cl_command_queue) lua_touserdata(L, 1), param_name, sizeof(cl_context), &param_value_context, NULL);
            (err != CL_SUCCESS) ? lua_pushnil(L) : lua_pushlightuserdata(L, param_value_context);
            return 1;

        case CL_QUEUE_DEVICE            : // cl_device_id
            err = clGetCommandQueueInfo((cl_command_queue) lua_touserdata(L, 1), param_name, sizeof(cl_device_id), &param_value_device, NULL);
            (err != CL_SUCCESS) ? lua_pushnil(L) : lua_pushlightuserdata(L, param_value_device);
            return 1;
        case CL_QUEUE_REFERENCE_COUNT   : // cl_uint
            err = clGetCommandQueueInfo((cl_command_queue) lua_touserdata(L, 1), param_name, sizeof(cl_uint), &param_value_ref_count, NULL);
            (err != CL_SUCCESS) ? lua_pushnil(L) : lua_pushnumber(L, param_value_ref_count);
            return 1;
        case CL_QUEUE_PROPERTIES        : // cl_command_queue_properties
            err = clGetCommandQueueInfo((cl_command_queue) lua_touserdata(L, 1), param_name, sizeof(cl_command_queue_properties), &param_value_props, NULL);
            (err != CL_SUCCESS) ? lua_pushnil(L) : lua_pushnumber(L, param_value_props);
            return 1;
        default                         :
            lua_pushnil(L);
            return 1;
    }
}
//----------------------------------------------------------------
/******************************************************************************************************************DEPRECATED*/
#ifndef CL_VERSION_1_1
static int setCommandQueueProperty(lua_State * L)
{
    cl_command_queue_properties old_properties = 0;
    cl_command_queue_properties new_properties = (cl_command_queue_properties) get_enum(L, 2);

    err = clSetCommandQueueProperty((cl_command_queue) lua_touserdata(L, 1), new_properties, (cl_bool) lua_tonumber(L, 3), &old_properties );
    (err != CL_SUCCESS) ? lua_pushnil(L) : lua_pushnumber(L, old_properties);
    return 1;
}
#endif
/****************************************************************************************************************************/
static int createContextFromType(lua_State * L)
{
    unsigned int            i;
    cl_context              context;
    size_t                  num_properties;
    cl_device_type          device_type;
    cl_context_properties * properties;

    device_type     = (cl_device_type) get_enum(L, 2);
    num_properties  = lua_objlen(L, 1);

    if(num_properties % 2 == 0) num_properties++;
    properties = (cl_context_properties *) malloc(num_properties * sizeof(cl_context_properties));

    for(i = 0; i < num_properties - 1; i++)
    {
        lua_rawgeti(L, 1, i+1);
        if(i % 2 == 0)
            properties[i] = (cl_context_properties) lua_tonumber(L, -1);
        else
            properties[i] = (cl_context_properties)(cl_platform_id) lua_touserdata(L, -1);
        lua_remove(L, -1);
    }
    properties[i] = 0;

    context = clCreateContextFromType(properties, device_type, NULL, NULL, &err);

    (err != CL_SUCCESS) ? lua_pushnil(L) : lua_pushlightuserdata(L, context);
    return 0;
}
static int createKernelsInProgram(lua_State * L)
{
    unsigned int    i;
    cl_kernel *     kernels;
    cl_uint         num_kernels;

    clCreateKernelsInProgram((cl_program) lua_touserdata(L, 1), 0, NULL, &num_kernels);
    kernels = (cl_kernel *) malloc(num_kernels * sizeof(cl_kernel));
    err = clCreateKernelsInProgram((cl_program)lua_touserdata(L, 1), num_kernels * sizeof(cl_kernel), kernels, NULL);
    if(err != CL_SUCCESS)
        lua_pushnil(L);
    else
    {
        lua_newtable(L);
        for(i = 0; i < num_kernels; i++)
        {
            lua_pushlightuserdata(L, kernels[i]);
            lua_rawseti(L, -2, i+1);
        }
    }

    return 1;
}
//----------------------------------------------------------------
static int createUINTImage2D(lua_State * L)
{
    unsigned int    i;
    cl_mem_flags    flags;
    cl_image_format image_format;
    cl_mem          img;
    cl_uint *       host_ptr = NULL;
    size_t          image_width, image_height, image_row_pitch;

    lua_rawgeti(L, 3, 1);
    image_format.image_channel_order        = (cl_channel_order) get_enum(L, -1);
    lua_remove(L, -1);
    lua_rawgeti(L, 3, 2);
    image_format.image_channel_data_type    = (cl_channel_type) get_enum(L, -1);
    lua_remove(L, -1);

    flags = get_enum(L, 2);

    image_width     = (size_t) lua_tonumber(L, 4);
    image_height    = (size_t) lua_tonumber(L, 5);
    image_row_pitch = (size_t) lua_tonumber(L, 5);

    if((flags & CL_MEM_USE_HOST_PTR) || (flags & CL_MEM_COPY_HOST_PTR))
    {
        host_ptr = (cl_uint *) malloc((image_row_pitch * image_height) * sizeof(cl_uint));
        for(i = 0; i < (image_row_pitch * image_height); i++)
        {
            lua_rawgeti(L, 6, i+1);
            host_ptr[i] = (cl_uint) lua_tonumber(L, -1);
            lua_remove(L, -1);
        }

        img = clCreateImage2D ((cl_context) lua_touserdata(L, 1), flags, &image_format,
                                image_width, image_height, (size_t) lua_tonumber(L, 5) * sizeof(cl_uint), host_ptr, &err);
    }
    else
    {
        img = clCreateImage2D ((cl_context) lua_touserdata(L, 1), flags, &image_format,
                                image_width, image_height, 0, NULL, &err);
    }

    (err != CL_SUCCESS) ? lua_pushnil(L) : lua_pushlightuserdata(L, img);
    return 1;
}
static int createUINTImage3D(lua_State * L)
{
    unsigned int    i;
    cl_mem_flags    flags;
    cl_image_format image_format;
    cl_mem          img;
    cl_uint *       host_ptr = NULL;
    size_t          image_width, image_height, image_depth, image_slice_pitch, image_row_pitch;

    lua_rawgeti(L, 3, 1);
    image_format.image_channel_order        = (cl_channel_order) get_enum(L, -1);
    lua_remove(L, -1);
    lua_rawgeti(L, 3, 2);
    image_format.image_channel_data_type    = (cl_channel_type) get_enum(L, -1);
    lua_remove(L, -1);

    flags = get_enum(L, 2);

    image_width         = (size_t) lua_tonumber(L, 4);
    image_height        = (size_t) lua_tonumber(L, 5);
    image_depth         = (size_t) lua_tonumber(L, 6);
    image_row_pitch     = (size_t) lua_tonumber(L, 7);
    image_slice_pitch   = (size_t) lua_tonumber(L, 8);

    if((flags & CL_MEM_USE_HOST_PTR) || (flags & CL_MEM_COPY_HOST_PTR))
    {
        host_ptr = (cl_uint *) malloc((image_slice_pitch * image_depth) * sizeof(cl_uint));
        for(i = 0; i < (image_slice_pitch * image_depth); i++)
        {
            lua_rawgeti(L, 6, i+1);
            host_ptr[i] = (cl_uint) lua_tonumber(L, -1);
            lua_remove(L, -1);
        }

        img = clCreateImage3D ((cl_context) lua_touserdata(L, 1), flags, &image_format,
                               image_width, image_height, image_depth, image_row_pitch * sizeof(cl_uint),
                               image_slice_pitch * sizeof(cl_uint), host_ptr, &err);
    }
    else
    {
        img = clCreateImage3D ((cl_context) lua_touserdata(L, 1), flags, &image_format,
                               image_width, image_height, image_depth, 0,
                               0, NULL, &err);
    }

    (err != CL_SUCCESS) ? lua_pushnil(L) : lua_pushlightuserdata(L, img);
    return 1;
}
static int getSupportedImageFormats(lua_State * L)
{
    unsigned int        i;
    cl_mem_object_type  image_type;
    cl_mem_flags        flags;
    cl_uint             num_image_formats;
    cl_image_format *   image_formats;

    flags       = (cl_mem_flags) get_enum(L, 2);
    image_type  = (cl_mem_object_type) get_enum(L, 3);

    clGetSupportedImageFormats((cl_context) lua_touserdata(L, 1), flags, image_type, 0, NULL, &num_image_formats);
    image_formats = (cl_image_format *) malloc(sizeof(cl_image_format) * num_image_formats);

    err = clGetSupportedImageFormats((cl_context) lua_touserdata(L, 1), flags, image_type, num_image_formats, image_formats, NULL);
    if(err != CL_SUCCESS)
    {
        lua_pushnil(L);
    }
    else
    {
        lua_newtable(L);
        for(i = 0; i < num_image_formats; i++)
        {
            lua_pushnumber(L, image_formats[i].image_channel_order);
            lua_rawseti(L, -2, i+1);
            lua_pushnumber(L, image_formats[i].image_channel_data_type);
            lua_rawseti(L, -2, i+1);
        }
    }
    return 1;
}
static int createSampler(lua_State * L)
{
    cl_sampler          sampler;
    cl_filter_mode      filter_mode;
    cl_addressing_mode  addressing_mode;
    cl_bool             normalized_coords;

    normalized_coords   = (cl_bool) get_enum(L, 2);
    addressing_mode     = (cl_addressing_mode) get_enum(L, 3);
    filter_mode         = (cl_filter_mode) get_enum(L, 4);

    sampler = clCreateSampler((cl_context) lua_touserdata(L, 1), normalized_coords, addressing_mode, filter_mode, &err);
    (err != CL_SUCCESS) ? (lua_pushnil(L)) : (lua_pushlightuserdata(L, sampler));
    return 1;
}
static int retainMemObject(lua_State * L)
{
    clRetainMemObject((cl_mem) lua_touserdata(L, 1));
    return 0;
}
static int getMemObjectInfo(lua_State * L)
{
    cl_mem_object_type  param_name_object_type;
    cl_mem_flags        param_name_flags;
    size_t              param_name_size;
    cl_uint             param_name_uint;
    cl_context          param_name_context;
    cl_mem_info param_name = (cl_mem_info) get_enum(L, 2);

    switch(param_name)
    {
        case CL_MEM_TYPE            : // cl_mem_object_type
            err = clGetMemObjectInfo((cl_mem) lua_touserdata(L, 1), param_name, sizeof(cl_mem_object_type), &param_name_object_type, NULL);
            (err != CL_SUCCESS) ? lua_pushnil(L) : lua_pushnumber(L, param_name_object_type);
            return 1;
        case CL_MEM_FLAGS           : // cl_mem_flags
            err = clGetMemObjectInfo((cl_mem) lua_touserdata(L, 1), param_name, sizeof(cl_mem_flags), &param_name_flags, NULL);
            (err != CL_SUCCESS) ? lua_pushnil(L) : lua_pushnumber(L, param_name_flags);
            return 1;
        case CL_MEM_SIZE            : // size_t
            err = clGetMemObjectInfo((cl_mem) lua_touserdata(L, 1), param_name, sizeof(size_t), &param_name_size, NULL);
            (err != CL_SUCCESS) ? lua_pushnil(L) : lua_pushnumber(L, param_name_size);
            return 1;
        //case CL_MEM_HOST_PTR        : // void *
        case CL_MEM_MAP_COUNT       : // cl_uint
        case CL_MEM_REFERENCE_COUNT :
            err = clGetMemObjectInfo((cl_mem) lua_touserdata(L, 1), param_name, sizeof(cl_uint), &param_name_uint, NULL);
            (err != CL_SUCCESS) ? lua_pushnil(L) : lua_pushnumber(L, param_name_uint);
            return 1;
        case CL_MEM_CONTEXT         : // cl_context
            err = clGetMemObjectInfo((cl_mem) lua_touserdata(L, 1), param_name, sizeof(cl_context), &param_name_context, NULL);
            (err != CL_SUCCESS) ? lua_pushnil(L) : lua_pushlightuserdata(L, param_name_context);
            return 1;
        default                     :
            lua_pushnil(L);
            return 1;
    }
}
static int getImageInfo(lua_State * L)
{
    cl_image_format param_value_format;
    size_t          param_value_size;

    cl_image_info param_name = (cl_image_info) get_enum(L, 2);

    switch(param_name)
    {
        case CL_IMAGE_FORMAT        : // cl_image_format                                                        // !
            err = clGetImageInfo((cl_mem) lua_touserdata(L, 1), param_name, sizeof(cl_image_format), &param_value_format, NULL);
            if(err != CL_SUCCESS) {lua_pushnil(L); return 1;}
            lua_newtable(L);
            lua_pushnumber(L, param_value_format.image_channel_order); lua_rawseti(L, -2, 1);
            lua_pushnumber(L, param_value_format.image_channel_data_type); lua_rawseti(L, -2, 2);
            return 1;
        case CL_IMAGE_ELEMENT_SIZE  : // size_t
        case CL_IMAGE_ROW_PITCH     :
        case CL_IMAGE_SLICE_PITCH   :
        case CL_IMAGE_WIDTH         :
        case CL_IMAGE_HEIGHT        :
        case CL_IMAGE_DEPTH         :
            err = clGetImageInfo((cl_mem) lua_touserdata(L, 1), param_name, sizeof(size_t), &param_value_size, NULL);
            (err != CL_SUCCESS) ? lua_pushnil(L) : lua_pushnumber(L, param_value_size);
            return 1;
        default                     :
            lua_pushnil(L);
            return 1;
    }
}
static int retainSampler(lua_State * L)
{
    err = clRetainSampler((cl_sampler) lua_touserdata(L, 1));
    return 0;
}
static int releaseSampler(lua_State * L)
{
    err = clReleaseSampler((cl_sampler) lua_touserdata(L, 1));
    return 0;
}
static int getSamplerInfo(lua_State * L)
{
    cl_context  param_value_context;
    cl_uint     param_value_uint;

    cl_sampler_info param_name = (cl_sampler_info) get_enum(L, 2);

    switch(param_name)
    {
        case CL_SAMPLER_CONTEXT             :   // cl_context
            err = clGetSamplerInfo((cl_sampler) lua_touserdata(L, 1), param_name, sizeof(cl_context), &param_value_context, NULL);
            (err != CL_SUCCESS) ? lua_pushnil(L) : lua_pushlightuserdata(L, param_value_context);
            return 1;
        case CL_SAMPLER_REFERENCE_COUNT     :   // cl_uint
        case CL_SAMPLER_ADDRESSING_MODE     :
        case CL_SAMPLER_FILTER_MODE         :
        case CL_SAMPLER_NORMALIZED_COORDS   :
            err = clGetSamplerInfo((cl_sampler) lua_touserdata(L, 1), param_name, sizeof(cl_uint), &param_value_uint, NULL);
            (err != CL_SUCCESS) ? lua_pushnil(L) : lua_pushnumber(L, param_value_uint);
            return 1;
        default                             :
            lua_pushnil(L);
            return 1;
    }
}
static int retainProgram(lua_State * L)
{
    err = clRetainProgram ((cl_program) lua_touserdata(L, 1));
    return 0;
}
static int unloadCompiler(lua_State * L)
{
    err = clUnloadCompiler();
    return 0;
}
static int getProgramInfo(lua_State * L)
{
    unsigned int    i;
    size_t          size_ret;
    cl_uint         param_value_uint;
    cl_context      param_value_context;
    cl_device_id*   param_value_device;
    char*           param_value_char;

    cl_program_info param_name = (cl_program_info) get_enum(L, 2);

    switch(param_name)
    {
        case CL_PROGRAM_REFERENCE_COUNT : // cl_uint
        case CL_PROGRAM_NUM_DEVICES     :
            err = clGetProgramInfo((cl_program) lua_touserdata(L, 1), param_name, sizeof(cl_uint), &param_value_uint, NULL);
            (err != CL_SUCCESS) ? lua_pushnil(L) : lua_pushnumber(L, param_value_uint);
            return 1;
        case CL_PROGRAM_CONTEXT         : // cl_context
            err = clGetProgramInfo((cl_program) lua_touserdata(L, 1), param_name, sizeof(cl_context), &param_value_context, NULL);
            (err != CL_SUCCESS) ? lua_pushnil(L) : lua_pushlightuserdata(L, param_value_context);
            return 1;
        case CL_PROGRAM_DEVICES         : // cl_device_id[]
            clGetProgramInfo((cl_program) lua_touserdata(L, 1), param_name, 0, NULL, &size_ret);
            param_value_device = (cl_device_id *) malloc(sizeof(cl_device_id) * size_ret);
            err = clGetProgramInfo((cl_program) lua_touserdata(L, 1), param_name, sizeof(cl_device_id) * size_ret, param_value_device, NULL);
            if(err != CL_SUCCESS)
                lua_pushnil(L);
            else
            {
                lua_newtable(L);
                for(i = 0; i < size_ret/(sizeof(cl_device_id)); i++)
                {
                    lua_pushlightuserdata(L, param_value_device[i]);
                    lua_rawseti(L, -2, i+1);
                }
            }
            free(param_value_device);
            return 1;
        case CL_PROGRAM_SOURCE          : // char[]
            clGetProgramInfo((cl_program) lua_touserdata(L, 1), param_name, 0, NULL, &size_ret);
            param_value_char = (char *) malloc(sizeof(char) * size_ret);
            err = clGetProgramInfo((cl_program) lua_touserdata(L, 1), param_name, sizeof(char) * size_ret, param_value_char, NULL);
            (err != CL_SUCCESS) ? lua_pushnil(L) : lua_pushstring(L, param_value_char);
            free(param_value_char);
            return 1;
        default                         :
            lua_pushnil(L);
            return 1;
    }
    return 0;
}
static int retainKernel(lua_State * L)
{
    err = clRetainKernel((cl_kernel) lua_touserdata(L, 1));
    return 0;
}
static int getKernelInfo(lua_State * L)
{
    size_t          size_ret;
    char*           param_value_char;
    cl_uint         param_value_uint;
    cl_context      param_value_context;
    cl_program      param_value_program;
    cl_kernel_info  param_name = (cl_kernel_info) get_enum(L, 2);

    switch(param_name)
    {
        case CL_KERNEL_FUNCTION_NAME    :
            clGetKernelInfo((cl_kernel) lua_touserdata(L, 1), param_name, 0, NULL, &size_ret);
            param_value_char = (char *) malloc(sizeof(char) * size_ret);
            err = clGetKernelInfo((cl_kernel) lua_touserdata(L, 1), param_name, sizeof(char) * size_ret, param_value_char, NULL);
            (err != CL_SUCCESS) ? lua_pushnil(L) : lua_pushstring(L, param_value_char);
            free(param_value_char);
            return 1;
        case CL_KERNEL_NUM_ARGS         :
        case CL_KERNEL_REFERENCE_COUNT  :
            err = clGetKernelInfo((cl_kernel) lua_touserdata(L, 1), param_name, sizeof(cl_uint), &param_value_uint, NULL);
            (err != CL_SUCCESS) ? lua_pushnil(L) : lua_pushnumber(L, param_value_uint);
            return 1;
        case CL_KERNEL_CONTEXT          :
            err = clGetKernelInfo((cl_kernel) lua_touserdata(L, 1), param_name, sizeof(cl_context), &param_value_context, NULL);
            (err != CL_SUCCESS) ? lua_pushnil(L) : lua_pushlightuserdata(L, param_value_context);
            return 1;
        case CL_KERNEL_PROGRAM          :
            err = clGetKernelInfo((cl_kernel) lua_touserdata(L, 1), param_name, sizeof(cl_program), &param_value_program, NULL);
            (err != CL_SUCCESS) ? lua_pushnil(L) : lua_pushlightuserdata(L, param_value_context);
            return 1;
        default                         :
            lua_pushnil(L);
            return 1;
    }
    return 0;
}
static int getKernelWorkGroupInfo(lua_State * L)
{
    unsigned int                i;
    size_t                      param_value_size[3];
    cl_ulong                    param_value_ulong;
    cl_kernel_work_group_info   param_name = (cl_kernel_work_group_info) get_enum(L, 3);
    switch(param_name)
    {
        case CL_KERNEL_WORK_GROUP_SIZE          : // size_t
            err = clGetKernelWorkGroupInfo((cl_kernel) lua_touserdata(L, 1), (cl_device_id) lua_touserdata(L, 2),
                                            param_name, sizeof(size_t), &param_value_size[0], NULL);
            (err != CL_SUCCESS) ? lua_pushnil(L) : lua_pushnumber(L, param_value_size[0]);
            return 1;
        case CL_KERNEL_COMPILE_WORK_GROUP_SIZE  : // size_t[3]
            err = clGetKernelWorkGroupInfo((cl_kernel) lua_touserdata(L, 1), (cl_device_id) lua_touserdata(L, 2),
                                            param_name, sizeof(size_t) * 3, param_value_size, NULL);
            if(err != CL_SUCCESS)
                lua_pushnil(L);
            else
            {
                lua_newtable(L);
                for(i = 0; i < 3; i++)
                {
                    lua_pushnumber(L, param_value_size[i]);
                    lua_rawseti(L, -2, i+1);
                }
            }
            return 1;
        case CL_KERNEL_LOCAL_MEM_SIZE           : // cl_ulong
            err = clGetKernelWorkGroupInfo((cl_kernel) lua_touserdata(L, 1), (cl_device_id) lua_touserdata(L, 2),
                                            param_name, sizeof(cl_ulong), &param_value_ulong, NULL);
            (err != CL_SUCCESS) ? lua_pushnil(L) : lua_pushnumber(L, param_value_ulong);
            return 1;
        default                                 :
            lua_pushnil(L);
            return 1;
    }
    return 0;
}
static int waitForEvents(lua_State * L)
{
    unsigned int    i;
    cl_uint         num_events;
    cl_event*       event_list;

    num_events = lua_objlen(L, 1);
    event_list = (cl_event *) malloc(num_events * sizeof(cl_event));

    for(i = 0; i < num_events; i++)
    {
        lua_rawgeti(L, 2, i+1);
        event_list[i] = (cl_event) lua_touserdata(L, -1);
    }

    err = clWaitForEvents(num_events, (const cl_event *) event_list);
    return 0;
}
static int getEventInfo(lua_State * L)
{
    cl_int              param_value_int;
    cl_uint             param_value_uint;
    cl_command_queue    param_value_queue;
    cl_event_info       param_name = (cl_event_info) get_enum(L, 2);

    switch(param_name)
    {
        case CL_EVENT_COMMAND_QUEUE             :
            err = clGetEventInfo((cl_event) lua_touserdata(L, 1), param_name, sizeof(cl_command_queue), &param_value_queue, NULL);
            (err != CL_SUCCESS) ? lua_pushnil(L) : lua_pushlightuserdata(L, param_value_queue);
            return 1;
        case CL_EVENT_COMMAND_EXECUTION_STATUS  :
            err = clGetEventInfo((cl_event) lua_touserdata(L, 1), param_name, sizeof(cl_int), &param_value_int, NULL);
            (err != CL_SUCCESS) ? lua_pushnil(L) : lua_pushnumber(L, param_value_int);
            return 1;
        case CL_EVENT_COMMAND_TYPE              :
        case CL_EVENT_REFERENCE_COUNT           :
            err = clGetEventInfo((cl_event) lua_touserdata(L, 1), param_name, sizeof(cl_uint), &param_value_uint, NULL);
            (err != CL_SUCCESS) ? lua_pushnil(L) : lua_pushnumber(L, param_value_uint);
            return 1;
        default                                 :
            lua_pushnil(L);
            return 1;
    }
    return 0;
}
static int retainEvent(lua_State * L)
{
    err = clRetainEvent((cl_event) lua_touserdata(L, 1));
    return 0;
}
static int releaseEvent(lua_State * L)
{
    err = clReleaseEvent((cl_event) lua_touserdata(L, 1));
    return 0;
}
static int getEventProfilingInfo(lua_State * L)
{
    cl_ulong            param_value_ulong;
    cl_profiling_info   param_name = (cl_profiling_info) get_enum(L, 2);

    switch(param_name)
    {
        case CL_PROFILING_COMMAND_QUEUED    :
        case CL_PROFILING_COMMAND_SUBMIT    :
        case CL_PROFILING_COMMAND_START     :
        case CL_PROFILING_COMMAND_END       :
            err = clGetEventProfilingInfo((cl_event) lua_touserdata(L, 1), param_name, sizeof(cl_ulong), &param_value_ulong, NULL);
            (err != CL_SUCCESS) ? lua_pushnil(L) : lua_pushnumber(L, param_value_ulong);
            return 1;
        default                             :
            lua_pushnil(L);
            return 1;
    }
    return 0;
}
static int flush(lua_State * L)
{
    err = clFlush((cl_command_queue) lua_touserdata(L, 1));
    return 0;
}
static int createProgramWithBinary(lua_State * L)
{/*
    unsigned int    i;
    cl_program      program;
    cl_uint         num_devices;
    cl_device_id *  devices;
    size_t          num_binaries;
    char *          binary;
    FILE *          binary_file;
    long            file_size;
    unsigned char   binaries;

    num_binaries    = (size_t) lua_objlen(L, 3);
    binaries        = (unsigned char **) malloc(num_biaries * sizeof(unsigned char *));
    num_devices     = (cl_uint) lua_objlen(L, 2);
    devices         = (cl_device_id *) malloc(sizeof(cl_device_id) * num_devices);

    for(i = 0; i < num_devices; i++)
    {
        lua_rawgeti(L, 2, i+1);
        devices[i] = (cl_device_id) lua_touserdata(L, 2);
        lua_remove(L, -1);
    }

    for(i = 0; i < num_binaries; i++)
    {
        lua_rawgeti(L, 3, i+1);
        binary  = lua_tostring(L, -1);
        lua_remove(L, -1);
        binary_file = fopen(binary, "rb");
        fseek(binary_file, 0, SEEK_END);
        file_size = ftell(binary_file);
        binaries[i] = (unsigned char *) malloc(file_size * sizeof(unsigned char));
        fread(binaries[i], sizeof(unsigned char), )
    }

    cl_program clCreateProgramWithBinary ((cl_context) lua_touserdata(L, 1), num_devices, devices,

const size_t *lengths,
const unsigned char **binaries,
cl_int *binary_status,
cl_int *errcode_ret) */
    return 0;
} // binaries nazvy suborov
static int enqueueCopyUINTBuffer(lua_State * L)
{
    cl_event event;
    cl_uint         events_in_list = 0;
    cl_event *      event_list = NULL;

    events_in_list = get_events(&L, event_list, 7);

    err = clEnqueueCopyBuffer((cl_command_queue) lua_touserdata(L, 1), (cl_mem) lua_touserdata(L, 2), (cl_mem) lua_touserdata(L, 3), (size_t) lua_tonumber(L, 4),
                              (size_t) lua_tonumber(L, 5), (size_t) lua_tonumber(L, 6) * sizeof(cl_uint), events_in_list, event_list, &event);

    (err != CL_SUCCESS) ? lua_pushnil(L) : lua_pushlightuserdata(L, event);
    return 1;
}
static int enqueueReadImage(lua_State * L){return 1;}
static int enqueueWriteImage(lua_State * L){return 1;}
static int enqueueCopyImage(lua_State * L)
{
    unsigned int i;
    size_t      src_origin[3];
    size_t      dst_origin[3];
    size_t      region[3];
    cl_event    event;
    cl_uint     events_in_list = 0;
    cl_event *  event_list = NULL;

    for(i = 0; i < 3; i++)
    {
        lua_rawgeti(L, 4, i+1); src_origin[i]   = (size_t) lua_tonumber(L, -1); lua_remove(L, -1);
        lua_rawgeti(L, 5, i+1); dst_origin[i]   = (size_t) lua_tonumber(L, -1); lua_remove(L, -1);
        lua_rawgeti(L, 6, i+1); region[i]       = (size_t) lua_tonumber(L, -1); lua_remove(L, -1);
    }

    events_in_list = get_events(&L, event_list, 7);

    err = clEnqueueCopyImage((cl_command_queue) lua_touserdata(L, 1), (cl_mem) lua_touserdata(L, 2), (cl_mem) lua_touserdata(L, 3),
                             src_origin, dst_origin, region,
                             events_in_list, event_list, &event
                             );
    (err != CL_SUCCESS) ? lua_pushnil(L) : lua_pushlightuserdata(L, event);
    return 1;
}
static int enqueueCopyImageToBuffer(lua_State * L)
{
    unsigned int i;
    size_t      src_origin[3];
    size_t      region[3];
    cl_event    event;
    cl_uint     events_in_list = 0;
    cl_event *  event_list = NULL;

    for(i = 0; i < 3; i++)
    {
        lua_rawgeti(L, 4, i+1); src_origin[i]   = (size_t) lua_tonumber(L, -1); lua_remove(L, -1);
        lua_rawgeti(L, 5, i+1); region[i]       = (size_t) lua_tonumber(L, -1); lua_remove(L, -1);
    }

    events_in_list = get_events(&L, event_list, 7);
    err = clEnqueueCopyImageToBuffer((cl_command_queue) lua_touserdata(L, 1), (cl_mem) lua_touserdata(L, 2), (cl_mem) lua_touserdata(L, 3),
                                     src_origin, region, (size_t) lua_tonumber(L, 6),
                                     events_in_list, event_list, &event
                                     );

    (err != CL_SUCCESS) ? lua_pushnil(L) : lua_pushlightuserdata(L, event);
    return 1;
}
static int enqueueCopyBufferToImage(lua_State * L)
{
    unsigned int i;
    size_t      src_origin[3];
    size_t      region[3];
    cl_event    event;
    cl_uint     events_in_list = 0;
    cl_event *  event_list = NULL;

    for(i = 0; i < 3; i++)
    {
        lua_rawgeti(L, 5, i+1); src_origin[i]   = (size_t) lua_tonumber(L, -1); lua_remove(L, -1);
        lua_rawgeti(L, 6, i+1); region[i]       = (size_t) lua_tonumber(L, -1); lua_remove(L, -1);
    }

    events_in_list = get_events(&L, event_list, 7);

    err = clEnqueueCopyBufferToImage((cl_command_queue) lua_touserdata(L, 1), (cl_mem) lua_touserdata(L, 2), (cl_mem) lua_touserdata(L, 3),
                                     (size_t) lua_tonumber(L, 4), src_origin, region,
                                     events_in_list, event_list, &event
                                     );

    (err != CL_SUCCESS) ? lua_pushnil(L) : lua_pushlightuserdata(L, event);
    return 1;
}
//static int enqueueMapImage(lua_State * L){return 0;}    ///////////////////////MAPOVANIE ASI ROBIT NEBUDEM
//static int enqueueUnmapMemObject(lua_State * L){return 0;}
static int enqueueNativeKernel(lua_State * L){return 1;} /////////////////////////////////////////////////////???????????????????????????????
static int enqueueTask(lua_State * L)
{
    cl_event event;
    cl_uint         events_in_list = 0;
    cl_event *      event_list = NULL;

    events_in_list = get_events(&L, event_list, 3);

    clEnqueueTask((cl_command_queue) lua_touserdata(L, 1), (cl_kernel) lua_touserdata(L, 2), events_in_list, event_list, &event);
    (err != CL_SUCCESS) ? lua_pushnil(L) : lua_pushlightuserdata(L, event);
    return 1;
}
//----------------------------------------------------------------
static int enqueueMarker(lua_State * L)
{
    cl_event event;

    err = clEnqueueMarker((cl_command_queue) lua_touserdata(L, 1), &event);

    if(err != CL_SUCCESS)
        lua_pushnil(L);
    else
        lua_pushlightuserdata(L, event);
    return 1;
}
//----------------------------------------------------------------
static int enqueueWaitForEvents(lua_State * L)
{
    unsigned int i;
    cl_event * event_list;
    cl_uint num_events = (cl_uint) lua_objlen(L, 2);

    event_list = (cl_event *) malloc(num_events * sizeof(cl_event));

    for(i = 0; i < num_events; i++)
    {
        lua_rawgeti(L, 2, i+1);
        event_list[i] = (cl_event) lua_touserdata(L, -1);
        lua_remove(L, -1);
    }

    err = clEnqueueWaitForEvents((cl_command_queue) lua_touserdata(L, 1), num_events, event_list);
    return 0;
}
//----------------------------------------------------------------
static int enqueueBarrier(lua_State * L)
{
    clEnqueueBarrier((cl_command_queue) lua_touserdata(L, 1));
    return 0;
}

//---------------------------------------------------------
static const struct luaL_Reg LuaCL [] = {
    #ifdef _WIN32
    {"Time"                         , performaceTime},
    #endif
    {"GetPlatformIDs"               , getPlatformIDs},
    {"GetPlatformInfo"              , getPlatformInfo},
    {"GetDeviceIDs"                 , getDeviceIDs},
    {"GetDeviceInfo"                , getDeviceInfo},
    {"CreateContext"                , createContext},
    {"CreateContextFromType"        , createContextFromType},
    {"RetainContext"                , retainContext},
    {"ReleaseContext"               , releaseContext},
    {"CreateCommandQueue"           , createCommandQueue},
    {"RetainCommandQueue"           , retainCommandQueue},
    {"ReleaseCommandQueue"          , releaseCommandQueue},
    {"BufferUINT"                   , BufferUINT},
    {"CreateProgramWithSource"      , createProgramWithSource},
    {"BuildProgram"                 , buildProgram},
    {"GetProgramBuildInfo"          , getProgramBuildInfo},
    {"CreateKernel"                 , createKernel},
    {"SetKernelArg"                 , setKernelArg},
    {"EnqueueNDRangeKernel"         , enqueueNDRangeKernel},
    {"Finish"                       , finish},
    {"EnqueueMapBuffer"             , enqueueMapBuffer},
    {"EnqueueWriteUINTBuffer"       , enqueueWriteUINTBuffer},
    {"ReleaseKernel"                , releaseKernel},
    {"ReleaseProgram"               , releaseProgram},
    {"ReleaseMemObject"             , releaseMemObject},
    {"GetCLError"                   , getCLError},
    {"GetContextInfo"               , getContextInfo},
    {"GetCommandQueueInfo"          , getCommandQueueInfo},
    {"CreateImageUINT2D"            , createUINTImage2D},
    {"CreateUINTImage3D"            , createUINTImage3D},
    {"RetainMemObject"              , retainMemObject},
    {"GetSupportedImageFormats"     , getSupportedImageFormats},
    {"GetMemObjectInfo"             , getMemObjectInfo},
    {"GetImageInfo"                 , getImageInfo},
    {"CreateSampler"                , createSampler},
    {"RetainSampler"                , retainSampler},
    {"ReleaseSampler"               , releaseSampler},
    {"GetSamplerInfo"               , getSamplerInfo},
    {"CreateProgramWithBinary"      , createProgramWithBinary},
    {"RetainProgram"                , retainProgram},
    {"UnloadCompiler"               , unloadCompiler},
    {"GetProgramInfo"               , getProgramInfo},
    {"CreateKernelsInProgram"       , createKernelsInProgram},
    {"RetainKernel"                 , retainKernel},
    {"GetKernelInfo"                , getKernelInfo},
    {"GetKernelWorkGroupInfo"       , getKernelWorkGroupInfo},
    {"WaitForEvents"                , waitForEvents},
    {"GetEventInfo"                 , getEventInfo},
    {"RetainEvent"                  , retainEvent},
    {"ReleaseEvent"                 , releaseEvent},
    {"GetEventProfilingInfo"        , getEventProfilingInfo},
    {"Flush"                        , flush},
    {"EnqueueReadUINTBuffer"        , enqueueReadUINTBuffer},
    {"EnqueueCopyUINTBuffer"        , enqueueCopyUINTBuffer},
    {"EnqueueReadImage"             , enqueueReadImage},
    {"EnqueueWriteImage"            , enqueueWriteImage},
    {"EnqueueCopyImage"             , enqueueCopyImage},
    {"EnqueueCopyImageToBuffer"     , enqueueCopyImageToBuffer},
    {"EnqueueCopyBufferToImage"     , enqueueCopyBufferToImage},
    //{"EnqueueMapImage"              , enqueueMapImage},
    //{"EnqueueUnmapMemObject"        , enqueueUnmapMemObject},
    {"EnqueueTask"                  , enqueueTask},
    {"EnqueueNativeKernel"          , enqueueNativeKernel},
    {"EnqueueMarker"                , enqueueMarker},
    {"EnqueueWaitForEvents"         , enqueueWaitForEvents},
    {"EnqueueBarrier"               , enqueueBarrier},
#ifndef CL_VERSION_1_1
    {"SetCommandQueueProperty"      , setCommandQueueProperty},
#endif
    {NULL                           , NULL}
};
int get_enum_val(const char * str, int n)
{
    int i = 0;

    while(cl_const[i].cl != 0)
    {
        if(strncmp(str, cl_const[i].cl, n) == 0 && cl_const[i].cl[n] == 0)
            return cl_const[i].value;
        i++;
    }
  return -1;
}
int get_enum(lua_State * L, int position)
{
    const char * str;
    int retval = 0;
    int enum_value;
    int length = 0;
    int i;

    if(lua_isnumber(L, position))
        return lua_tonumber(L, position);

    str = luaL_checkstring(L, position);

    length = strlen(str);

    for(i = 0; i <= length; i++)
    {
        if((str[i] == ' ') || (str[i] == ',') || (str[i] == '\0'))
        {
            if(i != 0)
            {
                if((enum_value = get_enum_val(str, i)) == -1)
                   return -1;
                else
                    retval |= enum_value;

				str += i;
				length -= i;
				i = -1;
				if(i == length) break;
            }
            else
			{
				str++;
                i = -1;
				length--;
			}
        }
    }
    return retval;
}

static int luacl_register_enum(lua_State * L)
{
    int i;
    for (i = 0; ; i++)
    {
        if(cl_const[i].cl == NULL) return 1;
        lua_pushnumber(L, cl_const[i].value);
        lua_setfield(L, -2, cl_const[i].cl);
    }
}
/*
** Open library
*/
DLL_EXPORT int luaopen_LuaCl (lua_State *L) {
  luaL_register(L, "cl", LuaCL);
  luacl_register_enum(L);
  return 1;
}

#ifdef __cplusplus
}
#endif
